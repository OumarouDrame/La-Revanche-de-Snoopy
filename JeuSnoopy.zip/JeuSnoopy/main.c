
#include <stdio.h>
#include <conio.h>  //

#define  LIGNES 10
#define COLONNES 20
#define SNOOPY 'S'



void afficherGrille(int posX, int posY) {
    // Affichage de la grille
    for (int i = 0; i < LIGNES; i++) {

        for (int j = 0; j <COLONNES ; j++) {
            //if (i == posY && j == posX) {
               // printf("%c %c", 0x0B, 0xDB); // PERSO
                printf(".");

        }
        printf("\n"); //
    }
}

int main() {

    int posX = 10, posY = 5;// Position initiale du personnage
    char matrice[LIGNES][COLONNES];
    matrice[posX][posY]=SNOOPY;


    char deplacement;

    while (1) {
        afficherGrille(posX, posY);  // Affiche la grille avec le personnage

        printf("Utilisez les touches 'w', 'a', 's', 'd' pour vous deplacer (Q pour quitter): ");
        deplacement = getch(); // Récupère la touche appuyée

        if (deplacement == 'q' || deplacement == 'Q') {
            break; // Quitte le jeu si la touche Q est pressée
        }


        switch (deplacement) {
            case 'w':
                if (posY > 0) posY--; // Vers le haut
                break;
            case 'a':
                if (posX > 0) posX--; // Vers la gauche
                break;
            case 's':
                if (posY < LIGNES - 1) posY++; // Vers le bas
                break;
            case 'd':
                if (posX < COLONNES - 1) posX++; // Vers la droite
                break;
        }
    }


    return 0;
}

