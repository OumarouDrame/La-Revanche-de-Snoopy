#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//Dimensions de la matrice
#define lignes 10
#define colonnes 20

//Définition des élements de la matrice en macros
#define SNOOPY 'S'
#define OISEAU 'O'
#define POUSSABLE 'P'
#define CASSABLE 'C'
#define PIEGE 'K'
#define BALLE 'X'

// Définition des constantes pour les directions de la balle
#define DIRECTION_HAUT_GAUCHE 1
#define DIRECTION_HAUT_DROITE 2
#define DIRECTION_BAS_GAUCHE 3
#define DIRECTION_BAS_DROITE 4



// Fonction pour initialiser la matrice
void initialiserMatrice(char matrice[lignes][colonnes]) {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            matrice[i][j] = '.';
        }
    }

}

//fonctions de placement des élements dans la matrice
void PositionOiseaux(char matrice[lignes][colonnes]){
    // Placement des oiseaux dans les coins de la matrice avec la symbol 'O' stocké dans OISEAU
    matrice[0][0] = OISEAU;
    matrice[0][colonnes - 1] = OISEAU;
    matrice[lignes - 1][0] = OISEAU;
    matrice[lignes - 1][colonnes - 1] = OISEAU;
}

void PositionBlocPoussable(char matrice[lignes][colonnes]){
    // Placement de 3 blocs poussables (stocké dans POUSSABLE en macros)
    matrice[7][17] = POUSSABLE;
    matrice[3][13] = POUSSABLE;
    matrice[2][3] = POUSSABLE;
    matrice[5][5] = POUSSABLE;
}

void PositionBlocCassable(char matrice[lignes][colonnes]){
    // Placement de 3 blocs cassables (stocké dans CASSABLE en macros)
    matrice[6][19] = CASSABLE;
    matrice[4][0] = CASSABLE;
    matrice[1][10] = CASSABLE;
    matrice[9][6] = CASSABLE;
}

void PositionBlocPieges(char matrice[lignes][colonnes]){
    // Placement de 3 blocs pieges (stocké dans PIEGE en macros)
    matrice[0][2] = PIEGE;
    matrice[7][4] = PIEGE;
    matrice[1][18] = PIEGE;
    matrice[9][18] = PIEGE;
    matrice[6][9] = PIEGE;
}

//fonction d'affichage de la matrice
void AffichageMatrice(char matrice[lignes][colonnes]){
    // Affichage de la matrice
    for (int i = 0; i < lignes; i++) {
        for (int j = 0; j < colonnes; j++) {
            printf("%c ", matrice[i][j]);
        }
        printf("\n");
    }
}

// Fonction pour casser un bloc cassable
void casserBloc() {
    char acte[10];
    do {
        printf("\nEntrez \"casser\" pour casser le bloc : \n");

        scanf("%s", acte);

        // Vérifiez si l'action saisi est correcte pour casser le bloc
        if (strcmp(acte, "casser") != 0) {
            printf("\nAction incorrecte.\n");
        }
    } while (strcmp(acte, "casser") != 0);
    printf("\nBravo ! Vous avez reussi a casser le bloc\n");
}

// Fonction pour pousser un bloc poussable
void pousserBloc(int *blocDejaPousse) {

        char action[10];
        do {
            printf("\nEntrez \"pousser\" pour pousser le bloc :\n ");
            scanf("%s", action);

            // Vérifiez si l'action saisie est correcte pour pousser le bloc
            if (strcmp(action, "pousser") != 0) {
                printf("\nAction incorrecte.\n");
            }
        } while (strcmp(action, "pousser") != 0);

        printf("\nBravo ! Vous avez reussi a pousser le bloc\n");
        // Mettre à jour blocDejaPousse pour indiquer que le bloc a été poussé
        *blocDejaPousse = 1;

}

// Définition de la structure CoordonneesEtVies comme type de retour des fonctions suivantes
typedef struct {
    int coordonneeX;
    int coordonneeY;
    int vies;

    //compteur pousser le bloc 1 seule fois
    int blocDejaPousse;

} CoordonneesEtVies;

// Fonction de vérification si le pas suivant de snoopy en Haut correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies,int *blocDejaPousse ){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc();
        //Snoopy se deplace en haut
        coordonneeY--;

    } else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");

        printf("il y'a un bloc POUSSABLE\n");
        if(*blocDejaPousse == 0) {
            pousserBloc(blocDejaPousse);
            matrice[a-1][coordonneeX] = POUSSABLE;
            //Snoopy se deplace en haut
            coordonneeY--;
        }else {

            printf("Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");

        }

    } else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n ");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n ");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeY--;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;
    resultat.blocDejaPousse = *blocDejaPousse;


    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy en Bas correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies,int *blocDejaPousse){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc();
        //Snoopy se deplace en haut
        coordonneeY++;
    }
    else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        if(*blocDejaPousse == 0) {
            pousserBloc(blocDejaPousse);
            //Remplacer la case a+1 par P
            matrice[a + 1][coordonneeX] = POUSSABLE;
            //Snoopy se deplace en haut
            coordonneeY++;
        }else {
            //garder la position de snoopy et du Bloc poussable

            printf("Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");

        }
    }
    else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n ");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n ");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeY++;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;
    resultat.blocDejaPousse = *blocDejaPousse;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy à gauche correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies, int *blocDejaPousse) {
    CoordonneesEtVies resultat;

    if (matrice[coordonneeY][a] == CASSABLE) {
        printf("il y'a un bloc cassable\n");
        casserBloc();
        coordonneeX--;
    } else if (matrice[coordonneeY][a] == POUSSABLE) {
        printf("il y'a un bloc POUSSABLE\n");
        if(*blocDejaPousse == 0) {
            pousserBloc(blocDejaPousse);
            //Remplacer la case a-1 par P
            matrice[coordonneeY][a-1] = POUSSABLE;
            //Deplacer Snoopy
            coordonneeX--;
        }else {
            //garder la position de snoopy et du Bloc poussable
            //affichage d'un message
            printf("Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");

        }

    } else if (matrice[coordonneeY][a] == PIEGE) {
        printf("il y'a un bloc PIEGE\n");
        coordonneeX = coordonneeX;
        vies--;
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n");
        printf("Nombre de vies restantes = %d\n", vies);
    } else {
        coordonneeX--;
    }

    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;
    resultat.blocDejaPousse = *blocDejaPousse;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy à Droite correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies, int *blocDejaPousse){
    CoordonneesEtVies resultat;
    if(matrice[coordonneeY][a] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc();
        //Snoopy se deplace à droite
        coordonneeX++;
    } else if(matrice[coordonneeY][a] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        pousserBloc(blocDejaPousse);
        //Remplacer la case a+1 par P
        matrice[coordonneeY][a+1] = POUSSABLE;
        //Snoopy se deplace à droite
        coordonneeX++;
    } else if(matrice[coordonneeY][a] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeX = coordonneeX;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeX++;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;
    resultat.blocDejaPousse = *blocDejaPousse;

    return resultat;
}

// Fonction pour gérer la balle
void bougerBalle(char matrice[lignes][colonnes], int *balleX, int *balleY, int *directionBalle, int *viesSnoopy, int snoopyX, int snoopyY) {
    // Sauvegarder les anciennes coordonnées de la balle
    int ancienneX = *balleX;
    int ancienneY = *balleY;


    // Mettre à jour la position de la balle en diagonale
    if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
        (*balleX)--;
        (*balleY)--;
    } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
        (*balleX)++;
        (*balleY)--;
    } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
        (*balleX)--;
        (*balleY)++;
    } else if (*directionBalle == DIRECTION_BAS_DROITE) {
        (*balleX)++;
        (*balleY)++;
    }

    // Vérifier les rebonds sur les murs
    if (*balleX < 0 || *balleX >= colonnes) {
        // Inverser la direction horizontale
        if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
            *directionBalle = DIRECTION_HAUT_DROITE;
        } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
            *directionBalle = DIRECTION_BAS_DROITE;
        } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
            *directionBalle = DIRECTION_HAUT_GAUCHE;
        } else if (*directionBalle == DIRECTION_BAS_DROITE) {
            *directionBalle = DIRECTION_BAS_GAUCHE;
        }
    }

    if (*balleY < 0 || *balleY >= lignes) {
        // Inverser la direction verticale
        if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
            *directionBalle = DIRECTION_BAS_GAUCHE;
        } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
            *directionBalle = DIRECTION_BAS_DROITE;
        } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
            *directionBalle = DIRECTION_HAUT_GAUCHE;
        } else if (*directionBalle == DIRECTION_BAS_DROITE) {
            *directionBalle = DIRECTION_HAUT_DROITE;
        }
    }

    // Vérifier si la balle touche Snoopy
    if (*balleX == snoopyX && *balleY == snoopyY) {
        (*viesSnoopy)--;
        printf("La balle a touché Snoopy ! Vies restantes : %d\n", *viesSnoopy);
        // Remettre Snoopy à sa position initiale
        matrice[snoopyY][snoopyX] = '.';
        // Placer Snoopy dans une nouvelle position aléatoire
        do {
            snoopyX = rand() % colonnes;
            snoopyY = rand() % lignes;
        } while (matrice[snoopyY][snoopyX] == OISEAU || matrice[snoopyY][snoopyX] == POUSSABLE || matrice[snoopyY][snoopyX] == CASSABLE || matrice[snoopyX][snoopyY] == PIEGE);

        matrice[snoopyY][snoopyX] = SNOOPY;
    }


    // Remplacer l'ancienne position par un point ('.') pour indiquer que la case est vide
    matrice[ancienneY][ancienneX] = '.';

    // Afficher la balle dans la matrice
    matrice[*balleY][*balleX] = BALLE;
}

/////////////// fonction principale de niveau 1 ///////////////

///prototype de la fonction sauvegrade ///
void sauvegarderPartie(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX,int balleY,int directionBalle, char matrice[lignes][colonnes]);
///prototype de la fonction chargement ///
void chargerPartie(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]);

void niveau1charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]){

    int blocDejaPousse = 0;

    //Declaration de deux variables
    int CoordonneeXCase ;
    int CoordonneeYCase ;
    Matrice[snoopyY][snoopyX] = SNOOPY;
    Matrice[balleX][balleY] = BALLE;

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {
        AffichageMatrice(Matrice);

        // Demande à l'utilisateur de saisir une action spécifique
        printf("Entrez une action (h, b, g, d, pause) : \n");
        char action[10];
        scanf("%s", action);

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if (strcmp(action, "h") == 0 && snoopyY > 0) {
            CoordonneeYCase = snoopyY-1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy,&blocDejaPousse);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;
            blocDejaPousse = resultatH.blocDejaPousse;
        }
        else if (strcmp(action, "b") == 0 && snoopyY < lignes - 1) {
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY+1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy,&blocDejaPousse);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;
            blocDejaPousse = resultatB.blocDejaPousse;
        }
        else if (strcmp(action, "g") == 0 && snoopyX > 0) {
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy,&blocDejaPousse);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;
            blocDejaPousse = resultatG.blocDejaPousse;
        }
        else if (strcmp(action, "d") == 0 && snoopyX < colonnes - 1) {
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy,&blocDejaPousse);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;
            blocDejaPousse = resultatD.blocDejaPousse;

        }
        else if (strcmp(action, "pause") == 0){
            int choice;
            printf("\nVous etes en pause\n");
            printf("1-reprendre le jeu\n");
            printf("2- Sauvegarder la partie et quitter\n");
            printf("3- Quitter");
            printf("\nEntrer votre choix :\n");
            scanf("%d", &choice);
            while(choice !=3){
                switch (choice){
                    case 1 :
                        printf("pause fini ...");
                        break;
                    case 2 :
                        sauvegarderPartie(viesSnoopy,oiseauxRestants,snoopyX,snoopyY,balleX, balleY, directionBalle,Matrice);
                        break;
                    case 3 :
                        exit(0);
                }

            }
        }
        else{
            printf("Attention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            printf("Felicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);
        }
        else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy,snoopyX,snoopyY);
    }

    //Vérification il y'a encore de oiseau à collecter ou si snoopy possede encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        printf("Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else {
        printf("Snoopy n'a plus de vies. Le jeu est termine.\n");
        exit(0);
    }
}




void niveau1Initiale(){

    //Nombre des vie de snoopy
    int viesSnoopy = 3;

    int blocDejaPousse = 0;
    //Nombre de oiseaux à recupérer
    int oiseauxRestants = 4;

    //Declaration de deux variables
    int CoordonneeXCase ;
    int CoordonneeYCase ;

    // Initialisation des coordonnées de la balle et de sa direction
    int balleX = 3;
    int balleY = 5;
    int directionBalle = DIRECTION_BAS_GAUCHE;

    // Déclaration de la matrice de type char
    char Matrice[lignes][colonnes];

    //Initialisation de la matrice
    initialiserMatrice( Matrice);

    //Position des Oiseaux dans la matrice
    PositionOiseaux(Matrice);

    //Position des Blocs Poussables dans la matrice
    PositionBlocPoussable(Matrice);

    //Position des Blocs Cassables dans la matrice
    PositionBlocCassable(Matrice);

    //Position des Blocs Pieges dans la matrice
    PositionBlocPieges(Matrice);


    //Coordonnées de Snoopy
    int snoopyX, snoopyY;

    // Placer Snoopy  dans une case où il n'a pas ni oiseaux ni blocs(cassable,Poussable,Pieges)
    do {
        snoopyX = rand() % colonnes;
        snoopyY = rand() % lignes;
    } while (Matrice[snoopyY][snoopyX] == OISEAU || Matrice[snoopyY][snoopyX] == POUSSABLE || Matrice[snoopyY][snoopyX] == CASSABLE || Matrice[snoopyX][snoopyY] == PIEGE);

    // Position initiale de Snoopy
    Matrice[snoopyY][snoopyX] = SNOOPY;

    // Afficher la balle dans la matrice
    Matrice[balleY][balleX] = BALLE;

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {
        AffichageMatrice(Matrice);

        // Demande à l'utilisateur de saisir une action spécifique
        printf("Entrez une action (h, b, g, d, pause) : \n");
        char action[10];
        scanf("%s", action);

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if (strcmp(action, "h") == 0 && snoopyY > 0) {
            CoordonneeYCase = snoopyY-1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy,&blocDejaPousse);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;
            blocDejaPousse = resultatH.blocDejaPousse;
        }
        else if (strcmp(action, "b") == 0 && snoopyY < lignes - 1) {
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY+1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy,&blocDejaPousse);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;
            blocDejaPousse = resultatB.blocDejaPousse;
        }
        else if (strcmp(action, "g") == 0 && snoopyX > 0) {
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy,&blocDejaPousse);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;
            blocDejaPousse = resultatG.blocDejaPousse;
        }
        else if (strcmp(action, "d") == 0 && snoopyX < colonnes - 1) {
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy,&blocDejaPousse);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;
            blocDejaPousse = resultatD.blocDejaPousse;

        }
        else if (strcmp(action, "pause") == 0){
            int choice;
            printf("\nVous etes en pause\n");
            printf("1- reprendre le jeu\n");
            printf("2- Sauvegarder la partie et quitter\n");
            printf("3- Quitter");
            printf("\nEntrer votre choix :\n");
            scanf("%d", &choice);
            while(choice !=3){
                switch (choice){
                    case 1 :
                        printf("pause fini ...");
                        break;
                    case 2 :
                        sauvegarderPartie(viesSnoopy,oiseauxRestants,snoopyX,snoopyY,balleX, balleY, directionBalle,Matrice);
                        exit(0);
                    case 3 :
                        exit(0);
                }

            }
        }
        else{
            printf("Attention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            printf("Felicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);
        }
        else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy,snoopyX,snoopyY);
    }

    //Vérification il y'a encore de oiseau à collecter ou si snoopy possede encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        printf("Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else {
        printf("Snoopy n'a plus de vies. Le jeu est termine.\n");
        exit(0);
    }
}


/////////////// sauvegarde de la partie ///////////////
void sauvegarderPartie(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY, int directionBalle, char matrice[lignes][colonnes]) {
    printf("sauvegarde en cours ...");
    FILE *fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie.txt", "w");
    if (fichierSauvegarde != NULL) {
        fprintf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fprintf(fichierSauvegarde, "%c ", matrice[i][j]);
            }
            fprintf(fichierSauvegarde, "\n");
        }
        fclose(fichierSauvegarde);
    } else {
        printf("Impossible de sauvegarder la partie.\n");
    }
}

///////////// chargement de la partie ///////////////
void chargerPartie(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]) {
    FILE *fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie.txt", "r");
    if (fichierSauvegarde != NULL) {
        fscanf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fscanf(fichierSauvegarde, " %c", &matrice[i][j]);
            }
        }
        fclose(fichierSauvegarde);
    } else {
        printf("Aucune sauvegarde trouvee.\n");
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////// Menu du jeu ////////////////////////////////////////////////////////////////////////////////////////////////////////////


// prototype de la focntion Menuprincipale
void MenuPrincipale();


void niveauxMenu(int niveauChoisi) {
    int choix = 0;
    int viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX,balleY,directionBalle;
    char Matrice[lignes][colonnes];
    while (choix != 3) {
        printf("\nNiveau %d\n", niveauChoisi);
        printf("1 - Reprendre une partie sauvegardee\n");
        printf("2 - Nouvelle partie\n");
        printf("3 - Retour au menu principal\n");
        printf("Choix : \n");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                // Reprendre une partie sauvegardée pour le niveau choisi
                chargerPartie(&viesSnoopy,&oiseauxRestants, &snoopyX, &snoopyY, &balleX, &balleY, &directionBalle, Matrice);
                printf("chargement du fichier \" C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie.txt\" en cours ...\n");
                niveau1charger(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,  Matrice);
                break;
            case 2:
                // Démarrer une nouvelle partie pour le niveau choisi
                niveau1Initiale();
                exit(0);
            case 3:
                //retour au menu pricipale par l'appel de la fonction MenuPrincipale
                MenuPrincipale();
                break;
            default:
                printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3.\n");
        }
    }
}

void sousMenuNiveaux() {
    int choixNiveau = 0;
    while (choixNiveau != 3) {
        printf("\nMenu Niveaux\n");
        printf("1 - Niveau 1\n");
        printf("2 - Niveau 2\n");
        printf("3 - Niveau 3\n");
        printf("Choix : \n");
        scanf("%d", &choixNiveau);

        switch (choixNiveau) {
            case 1:
            case 2:
            case 3:
                niveauxMenu(choixNiveau);
                break;
            default:
                printf("Choix invalide. Veuillez choisir un niveau de 1 a 3.\n");
        }
    }
}

void MenuPrincipale(){
    int choix = 0;
    while (choix != 2) {
        printf("\nMenu Principal\n");
        printf("1 - Niveaux\n");
        printf("2 - Exit\n");
        printf("Choix : \n");
        scanf("%d", &choix);

        switch (choix) {
            case 1:
                sousMenuNiveaux();
                break;
            case 2:
                printf("\nAu revoir!\n");
                break;
            default:
                printf("\nChoix invalide. Veuillez choisir 1 ou 2.\n");
        }
    }
}
