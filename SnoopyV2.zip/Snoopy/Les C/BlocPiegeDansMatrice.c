//
// Created by Oumarou Dramé on 01/11/2023.
//

#include "../Les H/StructureBlocPiege.h"
#include "../Les H/DimmensionMatrice.h"

void BlocPiegeDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE])
{
    matrice[NOMBRELIGNE/2][NOMBRECOLONNE+1] = 3;
}