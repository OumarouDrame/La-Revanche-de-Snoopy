//
// Created by Oumarou Dramé on 25/10/2023.
//

#include "../Les H/StructureSnoopy.h"
#include "../Les H/DimmensionMatrice.h"

void SnoopyDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Snoopy* snoopy)
{
    matrice[snoopy->positionLigne][snoopy->positionColonne] = 8;
}