//
// Created by Oumarou Dramé on 25/10/2023.
//

#include "../Les H/StructureOiseau.h"
#include "../Les H/DimmensionMatrice.h"

void OiseauDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE])
{
    matrice[0][0] = 9;
    matrice[0][NOMBRECOLONNE-1] = 9;
    matrice[NOMBRELIGNE-1][0] = 9;
    matrice[NOMBRELIGNE-1][NOMBRECOLONNE-1] = 9;
}
