//
// Created by Oumarou Dramé on 01/11/2023.
//
#include <stdio.h>
#include <stdlib.h>

int compteurOiseau = 4;

void CompteurOiseaux()
{

    compteurOiseau--;

    if(compteurOiseau > 1)
    {
        printf("Bravo, il reste %d oiseaux a recuperer\n", compteurOiseau);
    }
    else if(compteurOiseau == 1)
    {
        printf("Vite, plus qu'%d oiseau a recuperer !\n", compteurOiseau);
    }
    else {
        printf("Felicitation ! Tu as recupere tous les oiseaux !");
        exit(1);
    }
}
