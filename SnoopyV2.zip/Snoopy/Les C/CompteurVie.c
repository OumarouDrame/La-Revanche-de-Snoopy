//
// Created by Oumarou Dramé on 01/11/2023.
//

#include <stdio.h>
#include <stdlib.h>
#include "../Les H/StructureSnoopy.h"

int nombreVie = 3;

void CompteurVie()
{
    nombreVie--;

    if(nombreVie > 0)
    {
        printf("Snoopy vient de perdre une vie !\nSnoopy n'a plus que %d vies.\n", nombreVie);
    }
    else
    {
        printf("Snoopy n'a plus de vie. Fin du jeu.\n");
        exit(1);
    }
}
