#include <stdio.h>
#include <stdlib.h>
#include "Les H/DimmensionMatrice.h"
#include "Les H/AfficherMatrice.h"

#include "Les H/StructureSnoopy.h"
#include "Les H/StructureOiseau.h"
#include "Les H/StructureBalle.h"
#include "Les H/StructureBlocPoussable.h"
#include "Les H/StructureBlocPiege.h"
#include "Les H/StructureBlocCassable.h"

#include "Les H/SnoopyDansMatrice.h"
#include "Les H/OiseauDansMatrice.h"
#include "Les H/BalleDansMatrice.h"
#include "Les H/BlocPoussableDansMatrice.h"
#include "Les H/BlocPiegeDansMatrice.h"
#include "Les H/BlocCassableDansMatrice.h"

#include "Les H/DeplacementSnoopy.h"
#include "Les H/DeplacementBalle.h"



int main() {

    int matrice[NOMBRELIGNE][NOMBRECOLONNE] = {0};

    Snoopy snoopy = {NOMBRELIGNE/2,NOMBRECOLONNE/2};
    Oiseau oiseau;
    BlocPoussable blocPoussable1 = {NOMBRELIGNE/2-1,NOMBRECOLONNE/3, 1};
    BlocPoussable blocPoussable2 = {NOMBRELIGNE-2,NOMBRECOLONNE-2, 1};
    BlocCassable blocCassable = {NOMBRELIGNE/2-2, NOMBRECOLONNE/2};

    BlocPiege blocPiege;

    //Balle balle = {2,0};

    SnoopyDansMatrice(matrice, &snoopy);
    OiseauDansMatrice(matrice);
    BlocPoussableDansMatrice(matrice, &blocPoussable1, &blocPoussable2);
    BlocCassableDansMatrice(matrice, &blocCassable);
    BlocPiegeDansMatrice(matrice);

    //BalleDansMatrice(matrice, &balle);

    do
    {
    AfficherMatrice(matrice);
    DeplacementSnoopy(matrice, &snoopy, &blocPoussable1, &blocPoussable2, &blocCassable);
    //DeplacementBalle(matrice, &balle);
    } while (1);

    return 0;
}
