//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_BLOCPIEGEDANSMATRICE_H
#define SNOOPY_BLOCPIEGEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BlocPiegeDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE]);

#endif //SNOOPY_BLOCPIEGEDANSMATRICE_H
