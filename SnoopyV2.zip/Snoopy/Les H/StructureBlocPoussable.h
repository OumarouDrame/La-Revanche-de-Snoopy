//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_STRUCTUREBLOCPOUSSABLE_H
#define SNOOPY_STRUCTUREBLOCPOUSSABLE_H

typedef struct BlocPoussable BlocPoussable;

struct BlocPoussable{
    int positionLigne;
    int positionColonne;
    int poussable;
};

#endif //SNOOPY_STRUCTUREBLOCPOUSSABLE_H
