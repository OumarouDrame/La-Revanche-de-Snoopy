//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_STRUCTUREBLOCCASSABLE_H
#define SNOOPY_STRUCTUREBLOCCASSABLE_H

typedef struct BlocCassable BlocCassable;

struct BlocCassable{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPY_STRUCTUREBLOCCASSABLE_H
