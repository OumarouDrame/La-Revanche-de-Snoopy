//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_BLOCCASSABLEDANSMATRICE_H
#define SNOOPY_BLOCCASSABLEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BlocCassableDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], BlocCassable* blocCassable);

#endif //SNOOPY_BLOCCASSABLEDANSMATRICE_H
