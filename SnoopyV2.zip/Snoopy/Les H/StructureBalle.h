//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_STRUCTUREBALLE_H
#define SNOOPY_STRUCTUREBALLE_H

typedef struct Balle Balle;

struct Balle{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPY_STRUCTUREBALLE_H
