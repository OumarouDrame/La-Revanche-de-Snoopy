//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_BLOCPOUSSABLEDANSMATRICE_H
#define SNOOPY_BLOCPOUSSABLEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BlocPoussableDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], BlocPoussable* blocPoussable1, BlocPoussable* blocPoussable2);

#endif //SNOOPY_BLOCPOUSSABLEDANSMATRICE_H
