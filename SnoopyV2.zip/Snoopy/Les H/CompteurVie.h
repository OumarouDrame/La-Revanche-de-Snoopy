//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_COMPTEURVIE_H
#define SNOOPY_COMPTEURVIE_H

void CompteurVie();

#endif //SNOOPY_COMPTEURVIE_H
