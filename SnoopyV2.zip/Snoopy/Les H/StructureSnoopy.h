//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_STRUCTURESNOOPY_H
#define SNOOPY_STRUCTURESNOOPY_H

typedef struct Snoopy Snoopy;

struct Snoopy{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPY_STRUCTURESNOOPY_H
