//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_COMPTEUROISEAUX_H
#define SNOOPY_COMPTEUROISEAUX_H

void CompteurOiseaux();

#endif //SNOOPY_COMPTEUROISEAUX_H
