//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_DEPLACEMENTSNOOPY_H
#define SNOOPY_DEPLACEMENTSNOOPY_H

#include "../Les H/DimmensionMatrice.h"

void DeplacementSnoopy(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Snoopy* snoopy, BlocPoussable* blocPoussable1, BlocPoussable* blocPoussable2, BlocCassable* blocCassable);

#endif //SNOOPY_DEPLACEMENTSNOOPY_H
