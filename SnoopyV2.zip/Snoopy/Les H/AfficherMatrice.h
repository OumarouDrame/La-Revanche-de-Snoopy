//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_AFFICHERMATRICE_H
#define SNOOPY_AFFICHERMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void AfficherMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE]);

#endif //SNOOPY_AFFICHERMATRICE_H
