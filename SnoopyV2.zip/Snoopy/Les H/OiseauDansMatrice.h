//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_OISEAUDANSMATRICE_H
#define SNOOPY_OISEAUDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void OiseauDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE]);

#endif //SNOOPY_OISEAUDANSMATRICE_H
