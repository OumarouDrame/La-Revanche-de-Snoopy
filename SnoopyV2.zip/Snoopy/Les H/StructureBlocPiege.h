//
// Created by Oumarou Dramé on 01/11/2023.
//

#ifndef SNOOPY_STRUCTUREBLOCPIEGE_H
#define SNOOPY_STRUCTUREBLOCPIEGE_H

typedef struct BlocPiege BlocPiege;

struct BlocPiege{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPY_STRUCTUREBLOCPIEGE_H
