//
// Created by oulag on 28/10/2023.
//

//Dimensions de la matrice
#define lignes 10
#define colonnes 20

#ifndef PROJETJEUSNOOPY_BIBLIOTHEQUES_H
#define PROJETJEUSNOOPY_BIBLIOTHEQUES_H


void Color(int couleurDuTexte,int couleurDeFond);
void initialiserMatrice(char matrice[lignes][colonnes]);
void PositionOiseaux(char matrice[lignes][colonnes]);
void PositionBlocPoussable(char matrice[lignes][colonnes]);
void PositionBlocCassableNiv1(char matrice[lignes][colonnes]);
void PositionBlocCassableNiv2(char matrice[lignes][colonnes]);
void PositionBlocCassableNiv3(char matrice[lignes][colonnes]);
void PositionBlocPiegesNiv1(char matrice[lignes][colonnes]);
void PositionBlocPiegesNiv2(char matrice[lignes][colonnes]);
void PositionBlocPiegesNiv3(char matrice[lignes][colonnes]);
void AffichageMatrice(char matrice[lignes][colonnes]);


typedef struct {
    int coordonneeX;
    int coordonneeY;
    int vies;

} CoordonneesEtVies;

typedef struct BlocPoussable {
    int positionLigne;
    int positionColonne;
    int poussable;
} BlocPoussable;

CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies);
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);

void casserBloc();
void pousserBloc(BlocPoussable* p);
void bougerBalle(char matrice[lignes][colonnes], int *balleX, int *balleY, int *directionBalle, int *viesSnoopy, int snoopyX, int snoopyY);


void sauvegarderPartie1(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX,int balleY,int directionBalle, char matrice[lignes][colonnes]);
void sauvegarderPartie2(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX,int balleY,int directionBalle, char matrice[lignes][colonnes]);
void sauvegarderPartie3(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX,int balleY,int directionBalle, char matrice[lignes][colonnes]);


void chargerPartie1(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle,int *secondesRestantes, char matrice[lignes][colonnes]);
void chargerPartie2(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]);
void chargerPartie3(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]);


//////////// fonction principale de niveau 1 //////////

void niveau1charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]);
void niveau1Initiale();

void niveau2charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]);
void niveau2Initiale();

void niveau3charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]);
void niveau3Initiale();


////////////  Menu du jeu //////////

void niveau1Menu(int niveauChoisi);
void niveau2Menu(int niveauChoisi);
void niveau3Menu(int niveauChoisi);
void sousMenuNiveaux();
void MenuRegles();
void MenuPrincipale();

#endif //PROJETJEUSNOOPY_BIBLIOTHEQUES_H
