#include <stdio.h>
#include "Bibliotheques.h"

int main() {



    MenuPrincipale();



    return 0;
}
