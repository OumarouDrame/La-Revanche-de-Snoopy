#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#include <conio.h>
#include <unistd.h>
#include "Bibliotheques.h"

//Dimensions de la matrice
#define lignes 10
#define colonnes 20

//Définition des élements de la matrice en macros
#define SNOOPY 'S'
#define OISEAU 'O'
#define POUSSABLE 'P'
#define CASSABLE 'C'
#define PIEGE 'K'
#define BALLE 'X'
#define VIE 'V'

//Declatation du temps initiale
#define TEMPS 120

//Définition des constantes pour les directions de la balle
#define DIRECTION_HAUT_GAUCHE 1
#define DIRECTION_HAUT_DROITE 2
#define DIRECTION_BAS_GAUCHE 3
#define DIRECTION_BAS_DROITE 4


// fonction d'affichage de couleurs
void Color(int couleurDuTexte,int couleurDeFond){
    HANDLE H=GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(H,couleurDeFond*16+couleurDuTexte);
}

// Fonction pour obtenir la largeur actuelle de la console afin de centrer la matrice
int GetConsoleWidth() {
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    GetConsoleScreenBufferInfo(GetStdHandle(STD_OUTPUT_HANDLE), &csbi);
    return csbi.srWindow.Right- csbi.srWindow.Left +1;
}



/***********************************************
  Algo de la fonction initialiserMatrice
    * IN :  matrice 10*20
    * OUT : matrice remplie par des "."
    * INOUT :
 ***********************************************/
void initialiserMatrice(char matrice[lignes][colonnes]) {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            matrice[i][j] = '.';
        }
    }

}


/***********************************************
  Algo de la fonction PositionOiseaux
    * IN :  matrice 10*20
    * OUT : matrice avec des coins rempli par les "O" designant les oiseaux
    * INOUT :
 ***********************************************/
void PositionOiseaux(char matrice[lignes][colonnes]){
    // Placement des oiseaux dans les coins de la matrice avec la symbol 'O' stocké dans OISEAU
    matrice[0][0] = OISEAU;
    matrice[0][colonnes - 1] = OISEAU;
    matrice[lignes - 1][0] = OISEAU;
    matrice[lignes - 1][colonnes - 1] = OISEAU;
}


/***********************************************
  Algo de la fonction PositionBlocCassableNiv1 pour niveau 1
    * IN :  matrice 10*20
    * OUT : matrice avec des cases remplie par "C" designant Bloc Cassable
    * INOUT :
 ***********************************************/
void PositionBlocCassableNiv1(char matrice[lignes][colonnes]){
    // Placement de 4 blocs cassables dans la matrice pour niveau 1
    matrice[6][19] = CASSABLE;
    matrice[4][0] = CASSABLE;
    matrice[1][10] = CASSABLE;
    matrice[9][6] = CASSABLE;
}


/***********************************************
  Algo de la fonction PositionBlocCassableNiv2 pour niveau 2
    * IN :  matrice 10*20
    * OUT : matrice avec des plus de cases Cassable que le niveau 1
    * INOUT :
 ***********************************************/
void PositionBlocCassableNiv2(char matrice[lignes][colonnes]){
    // Placement des blocs cassables dans la matrice pour niveau 2
    PositionBlocCassableNiv1(matrice);
    matrice[8][13] = CASSABLE;
    matrice[3][16] = CASSABLE;


}


/***********************************************
  Algo de la fonction PositionBlocCassableNiv3 pour niveau 3
    * IN :  matrice 10*20
    * OUT : matrice avec des plus de cases Cassable que le niveau 2
    * INOUT :
 ***********************************************/
void PositionBlocCassableNiv3(char matrice[lignes][colonnes]){
    // Placement des blocs cassables dans la matrice pour niveau 3
    PositionBlocCassableNiv2(matrice);
    matrice[6][12] = CASSABLE;
    matrice[5][5] = CASSABLE;

}



/***********************************************
  Algo de la fonction PositionBlocPiegesNiv1 pour niveau 1
    * IN :  matrice 10*20
    * OUT : matrice avec des cases remplie par "K" designant Bloc piegés
    * INOUT :
 ***********************************************/
void PositionBlocPiegesNiv1(char matrice[lignes][colonnes]){
    // Placement de 3 blocs pieges (stocké dans PIEGE en macros)
    matrice[0][2] = PIEGE;
    matrice[7][4] = PIEGE;
    matrice[1][18] = PIEGE;
    matrice[9][18] = PIEGE;
    matrice[6][9] = PIEGE;
}


/***********************************************
  Algo de la fonction PositionBlocPiegesNiv2 pour niveau 2
    * IN :  matrice 10*20
    * OUT : matrice avec plus de cases piegés que niveau 1
    * INOUT :
 ***********************************************/
void PositionBlocPiegesNiv2(char matrice[lignes][colonnes]){
    // Placement de 3 blocs pieges (stocké dans PIEGE en macros)
    PositionBlocPiegesNiv1(matrice);
    matrice[9][2] = PIEGE;
    matrice[4][6] = PIEGE;
    matrice[5][15] = PIEGE;
}


/***********************************************
  Algo de la fonction PositionBlocPiegesNiv3 pour niveau 3
    * IN :  matrice 10*20
    * OUT : matrice avec plus de cases piegés que niveau 2
    * INOUT :
 ***********************************************/
void PositionBlocPiegesNiv3(char matrice[lignes][colonnes]){
    // Placement de 3 blocs pieges (stocké dans PIEGE en macros)
    PositionBlocPiegesNiv2(matrice);
    matrice[5][1] = PIEGE;
    matrice[4][3] = PIEGE;
    matrice[2][3] = PIEGE;
    matrice[6][14] = PIEGE;
    matrice[3][17] = PIEGE;
    matrice[0][14] = PIEGE;
}


/***********************************************
  Algo de la fonction PositionBlocVieNiv3 pour niveau 3
    * IN :  matrice 10*20
    * OUT : matrice avec 3 Blocs facultatifs qui sont les BlocS "V" ou VIE
    * INOUT :
 ***********************************************/
void PositionBlocVieNiv3(char matrice[lignes][colonnes]){
    // Placement de 3 blocs Vies
    matrice[9][10] = VIE;
    matrice[0][15] = VIE;
    matrice[6][2] = VIE;


}


/***********************************************
  Algo de la fonction AffichageMatrice
    * IN :  matrice 10*20
    * OUT : matrice avec tous les élements du jeu
    * INOUT :
 ***********************************************/
void AffichageMatrice(char matrice[lignes][colonnes]) {
    //instance pour avoir une marge à
    int consoleWidth = GetConsoleWidth();

    // Calcul de l'espace à ajouter à gauche pour centrer la matrice
    int leftPadding = (consoleWidth - colonnes * 4) / 2;

    // Affichage de la matrice centrée
    for (int i = 0; i < lignes; i++) {

        // Ajout de l'espace à gauche pour centrer la ligne
        for (int k = 0; k < leftPadding; k++) {
            printf(" ");
        }

        for (int j = 0; j < colonnes; j++) {
            switch (matrice[i][j]) {
                case '.':
                    Color(15, 0);
                    break;
                case CASSABLE:
                    Color(14, 0);
                    break;
                case POUSSABLE:
                    Color(2, 0);
                    break;
                case PIEGE:
                    Color(12, 0);
                    break;
                case OISEAU:
                    Color(1, 0);
                    break;
                case SNOOPY:
                    Color(15, 0);
                    break;
                case VIE:
                    Color(5, 14);
                    break;
                default:
                    Color(15, 0);
                    break;
            }
            printf(" %c   ", matrice[i][j]);
        }
        printf("\n");

    }

}




// Définition des positions des blocs poussables
BlocPoussable blocsPoussables[] = {
        {7, 17, 0},
        {3, 13, 0},
        {2, 6, 0},
        {1, 3, 0},
        {3, 1, 0}

};




/***********************************************
  Algo de la fonction PositionBlocPoussable
    * IN :  matrice 10*20
    * OUT : matrice avec des cases remplie par "P" designant les Blocs poussables
    * INOUT :
 ***********************************************/
void PositionBlocPoussable(char matrice[lignes][colonnes]) {
    // Placement des blocs poussables dans la matrice
    for (int i = 0; i < sizeof(blocsPoussables) / sizeof(blocsPoussables[0]); ++i) {
        matrice[blocsPoussables[i].positionLigne][blocsPoussables[i].positionColonne] = POUSSABLE;
    }
}



/***********************************************
  Algo de la fonction casserBloc
    * IN :
    * OUT :
 ***********************************************/
void casserBloc() {
    char acte;
    do {
        printf("\nEntrez \" c \" pour casser le bloc : \n");
        acte= getch();

    } while (acte != 'c'|| acte == 'C' );
    printf("\nBravo ! Vous avez reussi a casser le bloc\n");
}



/***********************************************
  Algo de la fonction pousserBloc

    * IN :  pointeur sur une structure bloc poussable

    * OUT : strcture modifier du bloc poussable
    (l'entier poussable de la structure devient =1 ) si le bloc est poussable donc
    on pourra pas le pousser une deuxieme fois

 ***********************************************/
void pousserBloc(BlocPoussable* p){
    char action;

    do {
        printf("\nEntrez 'p' pour pousser le bloc : ");
        action = getch();

    } while (action != 'p');

    printf("\nBravo ! Vous avez reussi a pousser le bloc\n");

    // Mettre à jour poussable pour indiquer que le bloc a été poussé
    p->poussable = 1;
}



/***********************************************
  Algo de la fonction VerifierHaut :
 Fonction de vérification si le pas suivant de snoopy en Haut correspond à un Bloc cassable, poussable, piege ou vide

    * IN :  matrice 10*20, coordonnee de snoopy(coordonneeY,coordonneeX),entier designant le pas suivant de snoopy suivant les lignes, nbre de vies.

    * OUT : structure CoordonneesEtVies
 ***********************************************/
CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies) {
    CoordonneesEtVies resultat;
    if (matrice[a][coordonneeX] == CASSABLE) {
        printf("il y'a un bloc cassable\n ");
        casserBloc();
        //Snoopy se deplace en haut
        coordonneeY--;

    } else if (matrice[a][coordonneeX] == POUSSABLE) {
        printf("il y'a un bloc POUSSABLE\n");
        // Vérification si les coordonnées correspondent à un bloc poussable
        for (int i = 0; i < sizeof(blocsPoussables) / sizeof(blocsPoussables[0]); ++i) {
            if (a == blocsPoussables[i].positionLigne &&
                coordonneeX == blocsPoussables[i].positionColonne) {
                if (blocsPoussables[i].poussable == 0) {
                    pousserBloc(&blocsPoussables[i]);
                    blocsPoussables[i].poussable = 1;
                    // Mettre à jour la position du bloc poussable
                    blocsPoussables[i].positionLigne = a - 1;
                    // Remplacer la case a+1 par P
                    matrice[a - 1][coordonneeX] = POUSSABLE;
                    //Snoopy se deplace en haut
                    coordonneeY--;

                } else {
                    printf("Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");
                }
            }
        }

    } else if (matrice[a][coordonneeX] == PIEGE) {
        vies = vies - 1;
        Color(4, 0);
        printf("\n\n  il y'a un bloc PIEGE\n");
        Color(4, 0);
        printf("  Attention ! vous etes passe par un bloc piege\n");
        Color(4, 0);
        printf("  Malheureusement Snoopy a perdu une vie\n\n");
        printf("  Nombre de vie restante = %d\n", vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas
    }
    else if (matrice[a][coordonneeX] == VIE) {
        if (vies == 3) {
            Color(15, 4);
            printf("\n\n  Yumm! vous avez gagne une vie \n ");
            //Snoopy se deplace en haut
            coordonneeY--;
        } else if (vies < 3) {
            Color(11, 0);
            printf("\n\n  Yumm! vous avez gagne une vie \n ");
            vies = vies + 1;
            printf("\n  Nombre de vie est devenu = %d\n",vies);
            //Snoopy se deplace en haut
            coordonneeY--;
        }
    }
    else {
            //Snoopy se deplace en haut
            coordonneeY--;

        }
        // Remplir la structure avec les coordonnées et le nombre de vies
        resultat.coordonneeX = coordonneeX;
        resultat.coordonneeY = coordonneeY;
        resultat.vies = vies;

        return resultat;
}




/***********************************************
  Algo de la fonction VerifierBas :
// Fonction de vérification si le pas suivant de snoopy en Bas correspond à un Bloc cassabe, poussable, piege ou vide

    * IN :  matrice 10*20, coordonnee de snoopy(coordonneeY,coordonneeX),entier designant le pas suivant de snoopy suivant les lignes, nbre de vies.

    * OUT : structure CoordonneesEtVies
 ***********************************************/
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("\n Il y'a un bloc cassable\n ");
        casserBloc();
        //Snoopy se deplace en bas
        coordonneeY++;

    }
    else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("\n Il y'a un bloc POUSSABLE\n");
        // Vérification si les coordonnées correspondent à un bloc poussable
        for (int i = 0; i < sizeof(blocsPoussables) / sizeof(blocsPoussables[0]); ++i) {
            if (a == blocsPoussables[i].positionLigne &&
                coordonneeX == blocsPoussables[i].positionColonne) {
                if (blocsPoussables[i].poussable == 0) {
                    pousserBloc(&blocsPoussables[i]);
                    blocsPoussables[i].poussable = 1;
                    // Mettre à jour la position du bloc poussable
                    blocsPoussables[i].positionLigne = a + 1;
                    // Remplacer la case a+1 par P
                    matrice[a + 1][coordonneeX] = POUSSABLE;
                    //Snoopy se deplace en bas
                    coordonneeY++;

                } else {
                    Color(4, 0);
                    printf("\n  Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");
                }
            }
        }
    }

    else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        Color(4, 0);
        printf("\n\n  Il y'a un bloc PIEGE\n");
        Color(4, 0);
        printf("  Attention ! vous etes passe par un bloc piege\n");
        Color(4, 0);
        printf("  Malheureusement Snoopy a perdu une vie\n\n");

        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas


    }
    else if (matrice[a][coordonneeX] == VIE) {
        if (vies == 3) {
            Color(15, 4);
            printf("\n\n  Yumm! vous avez gagne une vie \n ");
            //Snoopy se deplace en haut
            coordonneeY++;
        } else if (vies < 3) {
            Color(11, 0);
            printf("\n\n  Yumm! vous avez gagne une vie \n ");
            vies = vies + 1;
            printf("\n  Nombre de vie est devenu = %d\n",vies);
            //Snoopy se deplace en bas
            coordonneeY++;
        }
    }




    else{
        //Snoopy se deplace à droite
        coordonneeY++;

    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;


    return resultat;
}



/***********************************************
  Algo de la fonction VerifierGauche :
// Fonction de vérification si le pas suivant de snoopy à gauche correspond à un Bloc cassabe, poussable, piege ou vide

    * IN :  matrice 10*20, coordonnee de snoopy(coordonneeY,coordonneeX),entier designant le pas suivant de snoopy suivant les lignes, nbre de vies.

    * OUT : structure CoordonneesEtVies
 ***********************************************/
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies) {
    CoordonneesEtVies resultat;

    if (matrice[coordonneeY][a] == CASSABLE) {
        printf("il y'a un bloc cassable\n");
        casserBloc();
        //Deplacer Snoopy vers la gauche
        coordonneeX-- ;
    } else if (matrice[coordonneeY][a] == POUSSABLE) {
        printf("il y'a un bloc POUSSABLE\n");
        // Vérification si les coordonnées correspondent à un bloc poussable
        for (int i = 0; i < sizeof(blocsPoussables) / sizeof(blocsPoussables[0]); ++i) {
            if (coordonneeY == blocsPoussables[i].positionLigne &&
                a == blocsPoussables[i].positionColonne) {
                if (blocsPoussables[i].poussable == 0) {
                    pousserBloc(&blocsPoussables[i]);
                    blocsPoussables[i].poussable = 1;
                    // Mettre à jour la position du bloc poussable
                    blocsPoussables[i].positionColonne = a - 1;
                    // Remplacer la case a+1 par P
                    matrice[coordonneeY][a-1] = POUSSABLE;
                    //Deplacer Snoopy vers la gauche
                    coordonneeX-- ;

                } else {
                    printf("Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");
                }
            }
        }

    } else if (matrice[coordonneeY][a] == PIEGE) {
        coordonneeX = coordonneeX;
        vies--;
        Color(4, 0);
        printf("\n\n  il y'a un bloc PIEGE\n");
        Color(4, 0);
        printf("  Attention ! vous etes passe par un bloc piege\n");
        Color(4, 0);
        printf("  Malheureusement Snoopy a perdu une vie\n\n");
        printf("  Nombre de vie restante = %d\n", vies);


    }
    else if (matrice[coordonneeY][a]== VIE) {
        if (vies == 3) {
            Color(15, 4);
            printf("\n\nYumm! vous avez gagne une vie \n ");
            //Snoopy se deplace à gauche
            coordonneeX--;
        } else if (vies < 3) {
            Color(11, 0);
            printf("\n\nYumm! vous avez gagne une vie \n ");
            vies = vies + 1;
            printf("\nNombre de vie est devenu = %d\n",vies);
            //Deplacer Snoopy vers la gauche
            coordonneeX--;
        }
    }

    else {
        //Deplacer Snoopy vers la gauche
        coordonneeX-- ;

    }

    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}


/***********************************************
  Algo de la fonction VerifierDroite :
// Fonction de vérification si le pas suivant de snoopy à Droite correspond à un Bloc cassabe, poussable, piege ou vide

    * IN :  matrice 10*20, coordonnee de snoopy(coordonneeY,coordonneeX),entier designant le pas suivant de snoopy suivant les lignes, nbre de vies.

    * OUT : structure CoordonneesEtVies
 ***********************************************/
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[coordonneeY][a] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc();
        //Snoopy se deplace à droite
        coordonneeX++;

    } else if(matrice[coordonneeY][a] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        // Vérification si les coordonnées correspondent à un bloc poussable
        for (int i = 0; i < sizeof(blocsPoussables) / sizeof(blocsPoussables[0]); ++i) {

            if (coordonneeY == blocsPoussables[i].positionLigne &&
                a == blocsPoussables[i].positionColonne) {
                if (blocsPoussables[i].poussable == 0) {
                    pousserBloc(&blocsPoussables[i]);
                    blocsPoussables[i].poussable = 1;
                    // Mettre à jour la position du bloc poussable
                    blocsPoussables[i].positionColonne = a + 1;
                    // Remplacer la case a+1 par P
                    matrice[coordonneeY][a+1] = POUSSABLE;
                    //Snoopy se deplace à droite
                    coordonneeX++;

                } else {
                    printf("Ce bloc est deja pousse. Vous ne pouvez pas le repousser.\n");
                }
            }
        }

    } else if(matrice[coordonneeY][a] ==PIEGE){
        vies=vies-1;

        Color(4, 0);
        printf("\n\n  il y'a un bloc PIEGE\n");
        Color(4, 0);
        printf("  Attention ! vous etes passe par un bloc piege\n");
        Color(4, 0);
        printf("  Malheureusement Snoopy a perdu une vie\n\n");
        printf("  Nombre de vie restante = %d\n", vies);
        coordonneeX = coordonneeX;  //Les coordonnées de snoopy ne change pas


    }
    else if (matrice[coordonneeY][a] == VIE) {
        if (vies == 3) {
            Color(15, 4);
            printf("\n\nYumm! vous avez gagne une vie \n ");
            //snoppy se deplace vers la droite
            coordonneeX++;
        } else if (vies < 3) {
            Color(11, 0);
            printf("\n\nYumm! vous avez gagne une vie \n ");
            vies = vies + 1;
            printf("\nNombre de vie est devenu = %d\n",vies);
            //Snoopy se deplace à droite
            coordonneeX++;
        }
    }
    else{
        //Snoopy se deplace à droite
        coordonneeX++;

    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}




/***********************************************
  Algo de la fonction bougerBalle :
      Fonction pour gérer la balle

    * IN :  matrice 10*20, coordonnee de la balle, pointeur sur le nbre de vies, coordonnée de snoopy.

    * OUT :

    *INOUT : pointeur sur le nbre de vies (modification de nbre de vie en cas de collision de snoopy avec la balle), direction de la balle
 ***********************************************/
void bougerBalle(char matrice[lignes][colonnes], int *balleX, int *balleY, int *directionBalle, int *viesSnoopy, int snoopyX, int snoopyY) {
    // Sauvegarder les anciennes coordonnées de la balle
    int ancienneX = *balleX;
    int ancienneY = *balleY;

    // Vérifier si la balle touche Snoopy
    if (*balleX == snoopyX && *balleY == snoopyY) {
        system("cls");
        matrice[snoopyY][snoopyX] = SNOOPY;
        matrice[ancienneY][ancienneX] = '.'; // Effacer l'ancienne position de la balle
        (*viesSnoopy)--;
        printf("La balle a touche Snoopy ! Vies restantes : %d\n", *viesSnoopy);
    } else {
        // Mettre à jour la position de la balle en diagonale
        if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
            (*balleX)--;
            (*balleY)--;
        } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
            (*balleX)++;
            (*balleY)--;
        } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
            (*balleX)--;
            (*balleY)++;
        } else if (*directionBalle == DIRECTION_BAS_DROITE) {
            (*balleX)++;
            (*balleY)++;
        }

        // Vérifier les rebonds sur les murs
        if (*balleX < 0 || *balleX >= colonnes) {
            // Inverser la direction horizontale
            *balleX = ( *balleX < 0 ) ? 0 : colonnes - 1;
            if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
                *directionBalle = DIRECTION_HAUT_DROITE;
            } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
                *directionBalle = DIRECTION_BAS_DROITE;
            } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
                *directionBalle = DIRECTION_HAUT_GAUCHE;
            } else if (*directionBalle == DIRECTION_BAS_DROITE) {
                *directionBalle = DIRECTION_BAS_GAUCHE;
            }
        }

        if (*balleY < 0 || *balleY >= lignes) {
            // Inverser la direction verticale
            *balleY = ( *balleY < 0 ) ? 0 : lignes - 1;
            if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
                *directionBalle = DIRECTION_BAS_GAUCHE;
            } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
                *directionBalle = DIRECTION_BAS_DROITE;
            } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
                *directionBalle = DIRECTION_HAUT_GAUCHE;
            } else if (*directionBalle == DIRECTION_BAS_DROITE) {
                *directionBalle = DIRECTION_HAUT_DROITE;
            }
        }

        // Remplacer l'ancienne position par un point ('.') pour indiquer que la case est vide
        matrice[ancienneY][ancienneX] = '.';

        // Afficher la balle dans la matrice
        matrice[*balleY][*balleX] = BALLE;
    }
}



/***********************************************
  Algo de la fonction sauvegarderPartie1 :
// sauvegarde de la partie niveau 1

    * IN :   viesSnoopy,  oiseauxRestants,  snoopyX,  snoopyY, balleX,  balleY, directionBalle, matrice10*20

    * OUT : fin
 ***********************************************/
void sauvegarderPartie1(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY, int directionBalle,int secondes,char matrice[lignes][colonnes]) {
    printf("\n Sauvegarde de la partie est en cours ...");
    char action, act;
    FILE* fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie1.txt", "w");
    if (fichierSauvegarde != NULL) {
        fprintf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d\n\n", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY,directionBalle,secondes);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fprintf(fichierSauvegarde, "%c ", matrice[i][j]);
            }
            fprintf(fichierSauvegarde, "\n");
        }
        fclose(fichierSauvegarde);
    } else {
        printf("\n Impossible de sauvegarder la partie.\n");
    }
    printf("\nVous voulez quitter le jeu ou recommencer ?\n");
    printf("\n\t 'Q' -> quitter \t 'R' -> Menu Principale :\n");
    action = getch();
    act = toupper(action);

    switch(act){
        case 'Q':
            Color(14, 0);
            printf("Au revoir ! ");
            getchar();
        case 'R':
            sousMenuNiveaux();

    }
}

// sauvegarde de la partie niveau 2 ///////////////
void sauvegarderPartie2(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY, int directionBalle, char matrice[lignes][colonnes]) {
    printf("\n Sauvegarde de la partie est en cours ...");
    char action, act;
    FILE* fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie2.txt", "w");
    if (fichierSauvegarde != NULL) {
        fprintf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n\n", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fprintf(fichierSauvegarde, "%c ", matrice[i][j]);
            }
            fprintf(fichierSauvegarde, "\n");
        }
        fclose(fichierSauvegarde);
    } else {
        printf("\n Impossible de sauvegarder la partie.\n");
    }
    printf("\nVous voulez quitter le jeu ou recommencer ?\n");
    printf("\n\t 'Q' -> quitter \t 'R' -> Menu Principale :\n");
    action = getch();
    act = toupper(action);

    switch(act){
        case 'Q':
            Color(14, 0);
            printf("Au revoir ! ");
            getchar();
        case 'R':
            sousMenuNiveaux();

    }
}

// sauvegarde de la partie niveau 3 ///////////////
void sauvegarderPartie3(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY, int directionBalle, char matrice[lignes][colonnes]) {
    printf("\n Sauvegarde de la partie est en cours ...");
    char action, act;
    FILE* fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie3.txt", "w");
    if (fichierSauvegarde != NULL) {
        fprintf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n\n", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fprintf(fichierSauvegarde, "%c ", matrice[i][j]);
            }
            fprintf(fichierSauvegarde, "\n");
        }
        fclose(fichierSauvegarde);
    } else {
        printf("\n Impossible de sauvegarder la partie.\n");
    }
    printf("\nVous voulez quitter le jeu ou recommencer ?\n");
    printf("\n\t 'Q' -> quitter \t 'R' -> Menu Principale :\n");
    action = getch();
    act= toupper(action);
    switch(act){
        case 'Q':
            Color(14, 0);
            printf("\n\n Au revoir ! ");
            getchar();
        case 'R':
            sousMenuNiveaux();

    }


}

/////////////// 2 fonctions principale de niveau 1 (chargee ou initiale )///////////////
void niveau1charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle,int secondes, char Matrice[lignes][colonnes]){

    //Declaration de deux variables
    int CoordonneeXCase;
    int CoordonneeYCase;
    Matrice[snoopyY][snoopyX] = SNOOPY;

    // Initialisation du temps de début
    time_t tempsDebut = time(NULL);

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {

        Color(11, 0);
        printf("\n\n\tVies restante : %d\n\n",viesSnoopy);

        // Obtenez le temps actuel
        time_t tempsActuel = time(NULL);

        // Calculez le temps écoulé en secondes
        int tempsEcoule = tempsActuel - tempsDebut;

        // Votre boucle principale du jeu ici

        // Affichez le temps restant
        printf("\n\n\tTemps restant : %d secondes\n", TEMPS - tempsEcoule);

        // Ajoutez une pause d'une seconde entre chaque itération
        sleep((unsigned int) 0.2);


        char action;
        printf("\n\n");
        AffichageMatrice(Matrice);

        Color(5, 0);
        printf("\n\n Les actions possibles :\n\t h -> haut \t b ->bas \t g -> gauche \t d -> droite \t p -> pause \t c -> changer de niveau :\n");

        Color(15, 0);//violet
        // Demande à l'utilisateur de saisir une action spécifique
        printf("\n\nEntrez une action (h, b, g, d, p, c) : \n");
        // Utilisation de getch() pour lire une seule touche
        action = getch();

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if ((action == 'h'|| action == 'H') && snoopyY > 0) {
            system("cls");
            CoordonneeYCase = snoopyY - 1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;

        } else if ((action =='b' || action == 'B') && snoopyY < lignes - 1) {
            system("cls");
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY + 1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;

        } else if ((action == 'g'|| action == 'G') && snoopyX > 0) {
            system("cls");
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;

        } else if ((action== 'd'|| action == 'D') && snoopyX < colonnes - 1) {
            system("cls");
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;

        } else if (action == 'p'|| action == 'P' ) {
            system("cls");
            int choice;
            printf("\nVous etes en pause\n\n");
            printf("\t1- reprendre le jeu\n");
            printf("\t2- Sauvegarder la partie et quitter\n");
            printf("\t3- Quitter");
            printf("\n\nEntrer votre choix :\n");
            choice = getch();
            choice = atoi(&choice);
            switch (choice) {
                case 1 :
                    printf("\n\nPause finie ...\n");
                    break;
                case 2 :
                    sauvegarderPartie1(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,secondes,Matrice);
                    return;
                case 3 :
                    printf("Au revoir ! ");
                default:
                    printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3 ! \n");
                    printf("Choix : \n");
                    choice = getch();
            }
        }
        else if (action == 'c'|| action == 'C' ) {
            char choix;
            char mdp[10];

            do {

                printf("\nVous voulez passer a un autre niveau :\n");
                printf("\nChoisissez le niveau auquel vous voulez aller :\n");
                printf("\n Menu Niveaux : \n\n");
                printf("\t\t 2 - Niveau 2\n\n");
                printf("\t\t 3 - Niveau 3\n\n");

                choix = getch();
                choix = atoi(&choix);

                if (choix != 2 && choix != 3) {
                    system("cls");
                    printf("Choix invalide. Veuillez choisir 2 ou 3.\n");
                }

            } while (choix != 2 && choix != 3);  // Continuer à demander le choix tant qu'il n'est pas 2 ou 3

            switch (choix) {
                case 2:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau2\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau2\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau2Menu(choix);
                    break;

                case 3:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau3\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau3\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau3Menu(choix);
                    break;

            }
        }
        else {
            Color(4, 0); //rouge
            printf("\n\nAttention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            Color(11, 0);
            printf("\n\nFelicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);

        } else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy, snoopyX, snoopyY);

        // Ajoutez une condition pour vérifier si le temps est écoulé
        if (tempsEcoule >= TEMPS) {
            printf("\n\nLe temps est ecoule. Vous avez perdu une vie.\n");
            viesSnoopy--;

            // Réinitialisez le temps de début
            tempsDebut = time(NULL);
        }

    }

    // Vérification s'il reste encore des oiseaux à collecter ou si Snoopy possède encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        Color(11, 0);
        printf("\n\n Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else if (viesSnoopy == 0) {
        Color(4, 0);
        printf("\t\tSnoopy n'a plus de vies.\nVous avez perdu\n");
        sleep(2);
        Color(15, 0);
        MenuPrincipale();
    }


}

void niveau1Initiale() {

    //Nombre des vies de snoopy
    int viesSnoopy = 3;

    //Nombre de oiseaux à recupérer
    int oiseauxRestants = 4;

    //Declaration de deux variables
    int CoordonneeXCase;
    int CoordonneeYCase;

    // Initialisation des coordonnées de la balle et de sa direction
    int balleX = 3;
    int balleY = 2;
    int directionBalle = DIRECTION_BAS_GAUCHE;

    // Déclaration de la matrice de type char
    char Matrice[lignes][colonnes];

    //Initialisation de la matrice
    initialiserMatrice(Matrice);

    //Position des Oiseaux dans la matrice
    PositionOiseaux(Matrice);

    //Position des Blocs Poussables dans la matrice
    PositionBlocPoussable(Matrice);

    //Position des Blocs Cassables dans la matrice
    PositionBlocCassableNiv1(Matrice);

    //Position des Blocs Pieges dans la matrice
    PositionBlocPiegesNiv1(Matrice);


    //Coordonnées de Snoopy
    int snoopyX, snoopyY;

    // Placer Snoopy  dans une case aleatoire où il n'a pas ni oiseaux ni blocs(cassable,Poussable,Pieges)
    do {
        snoopyX = rand() % colonnes;
        snoopyY = rand() % lignes;
    } while (Matrice[snoopyY][snoopyX] == OISEAU || Matrice[snoopyY][snoopyX] == POUSSABLE ||
             Matrice[snoopyY][snoopyX] == CASSABLE || Matrice[snoopyX][snoopyY] == PIEGE|| Matrice[snoopyX][snoopyY] == VIE);

    // Position initiale de Snoopy
    Matrice[snoopyY][snoopyX] = SNOOPY;

    // Afficher la balle dans la matrice
    Matrice[balleY][balleX] = BALLE;

    // Initialisation du temps de début
    time_t tempsDebut = time(NULL);

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {

        Color(11, 0);
        printf("\n\n\tVies restante : %d\n\n",viesSnoopy);

        // Obtenez le temps actuel
        time_t tempsActuel = time(NULL);

        // Calculez le temps écoulé en secondes
        int tempsEcoule = tempsActuel - tempsDebut;

        int tempsRest = TEMPS - tempsEcoule;

        // Affichez le temps restant
        printf("\n\n\tTemps restant : %d secondes\n",tempsRest);

        // Ajoutez une pause d'une seconde entre chaque itération
        sleep((unsigned int) 0.2);

        char action;
        printf("\n\n");
        AffichageMatrice(Matrice);

        Color(5, 0);
        printf("\n\n Les actions possibles :\n\t h -> haut \t b ->bas \t g -> gauche \t d -> droite \t p -> pause \t c -> changer de niveau :\n");

        Color(15, 0);//violet
        // Demande à l'utilisateur de saisir une action spécifique
        printf("\n\nEntrez une action (h, b, g, d, p, c) : \n");
        // Utilisation de getch() pour lire une seule touche
        action = getch();

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if ((action == 'h'|| action == 'H') && snoopyY > 0) {
            system("cls");
            CoordonneeYCase = snoopyY - 1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;

        } else if ((action =='b' || action == 'B') && snoopyY < lignes - 1) {
            system("cls");
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY + 1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;

        } else if ((action == 'g'|| action == 'G') && snoopyX > 0) {
            system("cls");
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;

        } else if ((action== 'd'|| action == 'D') && snoopyX < colonnes - 1) {
            system("cls");
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;

        } else if (action == 'p'|| action == 'P' ) {
            system("cls");
            int choice;
            printf("\nVous etes en pause\n\n");
            printf("\t1- reprendre le jeu\n");
            printf("\t2- Sauvegarder la partie et quitter\n");
            printf("\t3- Quitter");
            printf("\n\nEntrer votre choix :\n");
            choice = getch();
            choice = atoi(&choice);
            switch (choice) {
                case 1 :
                    printf("\n\nPause finie ...\n");
                    break;
                case 2 :
                    sauvegarderPartie1(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,tempsRest,Matrice);
                    return;
                case 3 :
                    printf("Au revoir ! ");
                default:
                    printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3 ! \n");
                    printf("Choix : \n");
                    choice = getch();
            }
        }
        else if (action == 'c'|| action == 'C' ) {
            char choix;
            char mdp[10];

            do {

                printf("\nVous voulez passer a un autre niveau :\n");
                printf("\nChoisissez le niveau auquel vous voulez aller :\n");
                printf("\n Menu Niveaux : \n\n");
                printf("\t\t 2 - Niveau 2\n\n");
                printf("\t\t 3 - Niveau 3\n\n");

                choix = getch();
                choix = atoi(&choix);

                if (choix != 2 && choix != 3) {
                    system("cls");
                    printf("Choix invalide. Veuillez choisir 2 ou 3.\n");
                }

            } while (choix != 2 && choix != 3);  // Continuer à demander le choix tant qu'il n'est pas 2 ou 3

            switch (choix) {
                case 2:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau2\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau2\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau2Menu(choix);
                    break;

                case 3:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau3\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau3\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau3Menu(choix);
                    break;

            }
        }
        else {
            Color(4, 0); //rouge
            printf("\n\nAttention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            Color(11, 0);
            printf("\n\nFelicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);

        } else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy, snoopyX, snoopyY);

        // Ajoutez une condition pour vérifier si le temps est écoulé
        if (tempsEcoule >= TEMPS) {
            printf("\n\nLe temps est ecoule. Vous avez perdu une vie.\n");
            viesSnoopy--;

            // Réinitialisez le temps de début
            tempsDebut = time(NULL);
        }

    }

    // Vérification s'il reste encore des oiseaux à collecter ou si Snoopy possède encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        Color(11, 0);
        printf("\n\n Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else if (viesSnoopy == 0) {
        Color(4, 0);
        printf("\tSnoopy n'a plus de vies.\nVous avez perdu\n");
        sleep(2);
        Color(15, 0);
        MenuPrincipale();
    }


}

/////////////// 2 fonctions principale de niveau 2 (chargee ou initiale )///////////////
void niveau2charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]){
    int blocDejaPousse = 0;

    //Declaration de deux variables
    int CoordonneeXCase ;
    int CoordonneeYCase ;
    Matrice[snoopyY][snoopyX] = SNOOPY;
    // Initialisation du temps de début
    time_t tempsDebut = time(NULL);

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {

        Color(11, 0);
        printf("\n\n\tVies restante : %d\n\n",viesSnoopy);

        // Obtenez le temps actuel
        time_t tempsActuel = time(NULL);

        // Calculez le temps écoulé en secondes
        int tempsEcoule = tempsActuel - tempsDebut;

        // Votre boucle principale du jeu ici

        // Affichez le temps restant
        printf("\n\n\tTemps restant : %d secondes\n", TEMPS - tempsEcoule);

        // Ajoutez une pause d'une seconde entre chaque itération
        sleep((unsigned int) 0.2);

        char action;
        printf("\n\n");
        AffichageMatrice(Matrice);

        Color(5, 0);
        printf("\n\n Les actions possibles :\n\t h -> haut \t b ->bas \t g -> gauche \t d -> droite \t p -> pause \t c -> changer de niveau :\n");

        Color(15, 0);//violet
        // Demande à l'utilisateur de saisir une action spécifique
        printf("\n\nEntrez une action (h, b, g, d, p, c) : \n");
        // Utilisation de getch() pour lire une seule touche
        action = getch();

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if ((action == 'h'|| action == 'H') && snoopyY > 0) {
            system("cls");
            CoordonneeYCase = snoopyY - 1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;

        } else if ((action =='b' || action == 'B') && snoopyY < lignes - 1) {
            system("cls");
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY + 1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;

        } else if ((action == 'g'|| action == 'G') && snoopyX > 0) {
            system("cls");
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;

        } else if ((action== 'd'|| action == 'D') && snoopyX < colonnes - 1) {
            system("cls");
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;

        } else if (action == 'p'|| action == 'P' ) {
            system("cls");
            int choice;
            printf("\nVous etes en pause\n\n");
            printf("\t1- reprendre le jeu\n");
            printf("\t2- Sauvegarder la partie et quitter\n");
            printf("\t3- Quitter");
            printf("\n\nEntrer votre choix :\n");
            choice = getch();
            choice = atoi(&choice);
            switch (choice) {
                case 1 :
                    printf("\n\nPause finie ...\n");
                    break;
                case 2 :
                    sauvegarderPartie2(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,Matrice);
                    return;
                case 3 :
                    printf("Au revoir ! ");
                default:
                    printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3 ! \n");
                    printf("Choix : \n");
                    choice = getch();
            }
        }
        else if (action == 'c'|| action == 'C' ) {
            char choix;
            char mdp[10];

            do {

                printf("\nVous voulez passer a un autre niveau :\n");
                printf("\nChoisissez le niveau auquel vous voulez aller :\n");
                printf("\n Menu Niveaux : \n\n");
                printf("\t\t 1 - Niveau 1\n\n");
                printf("\t\t 3 - Niveau 3\n\n");

                choix = getch();
                choix = atoi(&choix);

                if (choix != 1 && choix != 3) {
                    system("cls");
                    printf("Choix invalide. Veuillez choisir 1 ou 3.\n");
                }

            } while (choix != 1 && choix != 3);  // Continuer à demander le choix tant qu'il n'est pas 2 ou 3

            switch (choix) {
                case 1:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau1\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau1\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau1Menu(choix);
                    break;

                case 2:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau3\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau3\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau3Menu(choix);
                    break;

            }
        }
        else {
            Color(4, 0); //rouge
            printf("\n\nAttention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            Color(11, 0);
            printf("\n\nFelicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);

        } else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy, snoopyX, snoopyY);

        // Ajoutez une condition pour vérifier si le temps est écoulé
        if (tempsEcoule >= TEMPS) {
            printf("\n\nLe temps est ecoule. Vous avez perdu une vie.\n");
            viesSnoopy--;

            // Réinitialisez le temps de début
            tempsDebut = time(NULL);
        }

    }

    //Vérification il y'a encore de oiseau à collecter ou si snoopy possede encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        Color(11, 0);
        printf("\tBravo ! Vous avez collecte tous les oiseaux.\n");
    } else {
        Color(4, 0);
        printf("\t\tSnoopy n'a plus de vies. \n\tVous avez perdu\n");
        sleep(2);
        Color(15, 0);
        MenuPrincipale();
    }

}

void niveau2Initiale() {


    //Nombre des vies de snoopy
    int viesSnoopy = 3;

    //Nombre de oiseaux à recupérer
    int oiseauxRestants = 4;

    //Declaration de deux variables
    int CoordonneeXCase;
    int CoordonneeYCase;

    // Initialisation des coordonnées de la balle et de sa direction
    int balleX = 3;
    int balleY = 2;
    int directionBalle = DIRECTION_BAS_GAUCHE;

    // Déclaration de la matrice de type char
    char Matrice[lignes][colonnes];

    //Initialisation de la matrice
    initialiserMatrice(Matrice);

    //Position des Oiseaux dans la matrice
    PositionOiseaux(Matrice);

    //Position des Blocs Poussables dans la matrice
    PositionBlocPoussable(Matrice);

    //Position des Blocs Cassables dans la matrice
    PositionBlocCassableNiv2(Matrice);

    //Position des Blocs Pieges dans la matrice
    PositionBlocPiegesNiv2(Matrice);


    //Coordonnées de Snoopy
    int snoopyX, snoopyY;

    // Placer Snoopy  dans une case aleatoire où il n'a pas ni oiseaux ni blocs(cassable,Poussable,Pieges)
    do {
        snoopyX = rand() % colonnes;
        snoopyY = rand() % lignes;
    } while (Matrice[snoopyY][snoopyX] == OISEAU || Matrice[snoopyY][snoopyX] == POUSSABLE ||
             Matrice[snoopyY][snoopyX] == CASSABLE || Matrice[snoopyX][snoopyY] == PIEGE);

    // Position initiale de Snoopy
    Matrice[snoopyY][snoopyX] = SNOOPY;


    // Afficher la balle dans la matrice
    Matrice[balleY][balleX] = BALLE;

    // Initialisation du temps de début
    time_t tempsDebut = time(NULL);

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {

        Color(11, 0);
        printf("\n\n\tVies restante : %d\n\n",viesSnoopy);

        // Obtenez le temps actuel
        time_t tempsActuel = time(NULL);

        // Calculez le temps écoulé en secondes
        int tempsEcoule = tempsActuel - tempsDebut;

        // Votre boucle principale du jeu ici

        // Affichez le temps restant
        printf("\n\n\tTemps restant : %d secondes\n", TEMPS - tempsEcoule);

        // Ajoutez une pause d'une seconde entre chaque itération
        sleep((unsigned int) 0.2);

        char action;
        printf("\n\n");
        AffichageMatrice(Matrice);

        Color(5, 0);
        printf("\n\n Les actions possibles :\n\t h -> haut \t b ->bas \t g -> gauche \t d -> droite \t p -> pause \t c -> changer de niveau :\n");

        Color(15, 0);//violet
        // Demande à l'utilisateur de saisir une action spécifique
        printf("\n\nEntrez une action (h, b, g, d, p, c) : \n");
        // Utilisation de getch() pour lire une seule touche
        action = getch();

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if ((action == 'h'|| action == 'H') && snoopyY > 0) {
            system("cls");
            CoordonneeYCase = snoopyY - 1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;

        } else if ((action =='b' || action == 'B') && snoopyY < lignes - 1) {
            system("cls");
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY + 1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;

        } else if ((action == 'g'|| action == 'G') && snoopyX > 0) {
            system("cls");
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;

        } else if ((action== 'd'|| action == 'D') && snoopyX < colonnes - 1) {
            system("cls");
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;

        } else if (action == 'p'|| action == 'P' ) {
            system("cls");
            int choice;
            printf("\nVous etes en pause\n\n");
            printf("\t1- reprendre le jeu\n");
            printf("\t2- Sauvegarder la partie et quitter\n");
            printf("\t3- Quitter");
            printf("\n\nEntrer votre choix :\n");
            choice = getch();
            choice = atoi(&choice);
            switch (choice) {
                case 1 :
                    printf("\n\nPause finie ...\n");
                    break;
                case 2 :
                    sauvegarderPartie2(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,Matrice);
                    return;
                case 3 :
                    printf("Au revoir ! ");
                default:
                    printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3 ! \n");
                    printf("Choix : \n");
                    choice = getch();
            }
        }
        else if (action == 'c'|| action == 'C' ) {
            char choix;
            char mdp[10];

            do {

                printf("\nVous voulez passer a un autre niveau :\n");
                printf("\nChoisissez le niveau auquel vous voulez aller :\n");
                printf("\n Menu Niveaux : \n\n");
                printf("\t\t 1 - Niveau 1\n\n");
                printf("\t\t 3 - Niveau 3\n\n");

                choix = getch();
                choix = atoi(&choix);

                if (choix != 1 && choix != 3) {
                    system("cls");
                    printf("Choix invalide. Veuillez choisir 1 ou 3.\n");
                }

            } while (choix != 1 && choix != 3);  // Continuer à demander le choix tant qu'il n'est pas 2 ou 3

            switch (choix) {
                case 1:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau1\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau1\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau1Menu(choix);
                    break;

                case 2:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau3\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau3\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau3Menu(choix);
                    break;

            }
        }
        else {
            Color(4, 0); //rouge
            printf("\n\nAttention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            Color(11, 0);
            printf("\n\nFelicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);

        } else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy, snoopyX, snoopyY);

        // Ajoutez une condition pour vérifier si le temps est écoulé
        if (tempsEcoule >= TEMPS) {
            printf("\n\nLe temps est ecoule. Vous avez perdu une vie.\n");
            viesSnoopy--;

            // Réinitialisez le temps de début
            tempsDebut = time(NULL);
        }

    }

    // Vérification s'il reste encore des oiseaux à collecter ou si Snoopy possède encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        Color(11, 0);
        printf("\n\n Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else if (viesSnoopy == 0) {
        Color(4, 0);
        printf("\t\tSnoopy n'a plus de vies. \n\tVous avez perdu\n");
        sleep(2);
        Color(15, 0);
        MenuPrincipale();
    }


}

/////////////// 2 fonctions principale de niveau 3 (chargee ou initiale )///////////////
void niveau3charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]){
    int blocDejaPousse = 0;

    //Declaration de deux variables
    int CoordonneeXCase ;
    int CoordonneeYCase ;
    Matrice[snoopyY][snoopyX] = SNOOPY;

    // Initialisation du temps de début
    time_t tempsDebut = time(NULL);

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {

        Color(11, 0);
        printf("\n\n\tVies restante : %d\n\n",viesSnoopy);

        // Obtenez le temps actuel
        time_t tempsActuel = time(NULL);

        // Calculez le temps écoulé en secondes
        int tempsEcoule = tempsActuel - tempsDebut;

        // Votre boucle principale du jeu ici

        // Affichez le temps restant
        printf("\n\n\tTemps restant : %d secondes\n", TEMPS - tempsEcoule);

        // Ajoutez une pause d'une seconde entre chaque itération
        sleep((unsigned int) 0.2);

        char action;
        printf("\n\n");
        AffichageMatrice(Matrice);

        Color(5, 0);
        printf("\n\n Les actions possibles :\n\t h -> haut \t b ->bas \t g -> gauche \t d -> droite \t p -> pause \t c -> changer de niveau :\n");

        Color(15, 0);//violet
        // Demande à l'utilisateur de saisir une action spécifique
        printf("\n\nEntrez une action (h, b, g, d, p, c) : \n");
        // Utilisation de getch() pour lire une seule touche
        action = getch();

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if ((action == 'h'|| action == 'H') && snoopyY > 0) {
            system("cls");
            CoordonneeYCase = snoopyY - 1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;

        } else if ((action =='b' || action == 'B') && snoopyY < lignes - 1) {
            system("cls");
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY + 1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;

        } else if ((action == 'g'|| action == 'G') && snoopyX > 0) {
            system("cls");
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;

        } else if ((action== 'd'|| action == 'D') && snoopyX < colonnes - 1) {
            system("cls");
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;

        } else if (action == 'p'|| action == 'P' ) {
            system("cls");
            int choice;
            printf("\nVous etes en pause\n\n");
            printf("\t1- reprendre le jeu\n");
            printf("\t2- Sauvegarder la partie et quitter\n");
            printf("\t3- Quitter");
            printf("\n\nEntrer votre choix :\n");
            choice = getch();
            choice = atoi(&choice);
            switch (choice) {
                case 1 :
                    printf("\n\nPause finie ...\n");
                    break;
                case 2 :
                    sauvegarderPartie3(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,Matrice);
                    return;
                case 3 :
                    printf("Au revoir ! ");
                default:
                    printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3 ! \n");
                    printf("Choix : \n");
                    choice = getch();
            }
        }
        else if (action == 'c'|| action == 'C' ) {
            char choix;
            char mdp[10];

            do {

                printf("\nVous voulez passer a un autre niveau :\n");
                printf("\nChoisissez le niveau auquel vous voulez aller :\n");
                printf("\n Menu Niveaux : \n\n");
                printf("\t\t 1 - Niveau 1\n\n");
                printf("\t\t 2 - Niveau 2\n\n");

                choix = getch();
                choix = atoi(&choix);

                if (choix != 1 && choix != 2) {
                    system("cls");
                    printf("Choix invalide. Veuillez choisir 1 ou 2.\n");
                }

            } while (choix != 1 && choix != 2);  // Continuer à demander le choix tant qu'il n'est pas 2 ou 3

            switch (choix) {
                case 1:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau1\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau1\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau1Menu(choix);
                    break;

                case 2:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau2\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau2\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau2Menu(choix);
                    break;

            }
        }
        else {
            Color(4, 0); //rouge
            printf("\n\nAttention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            Color(11, 0);
            printf("\n\nFelicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);

        } else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy, snoopyX, snoopyY);

        // Ajoutez une condition pour vérifier si le temps est écoulé
        if (tempsEcoule >= TEMPS) {
            printf("\n\nLe temps est ecoule. Vous avez perdu une vie.\n");
            viesSnoopy--;

            // Réinitialisez le temps de début
            tempsDebut = time(NULL);
        }

    }

    //Vérification il y'a encore de oiseau à collecter ou si snoopy possede encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        Color(11, 0);
        printf("\tBravo ! Vous avez collecte tous les oiseaux.\n");
    }
    else {
        Color(4, 0);
        printf("\t\tSnoopy n'a plus de vies. \n\tVous avez perdu\n");
        sleep(2);
        Color(15, 0);
        MenuPrincipale();
    }
}

void niveau3Initiale() {

    //Nombre des vies de snoopy
    int viesSnoopy = 3;

    //Nombre de oiseaux à recupérer
    int oiseauxRestants = 4;

    //Declaration de deux variables
    int CoordonneeXCase;
    int CoordonneeYCase;

    // Initialisation des coordonnées de la balle et de sa direction
    int balleX = 3;
    int balleY = 2;
    int directionBalle = DIRECTION_BAS_GAUCHE;

    // Déclaration de la matrice de type char
    char Matrice[lignes][colonnes];

    //Initialisation de la matrice
    initialiserMatrice(Matrice);

    //Position des Oiseaux dans la matrice
    PositionOiseaux(Matrice);

    //Position des Blocs Poussables dans la matrice
    PositionBlocPoussable(Matrice);

    //Position des Blocs Cassables dans la matrice
    PositionBlocCassableNiv3(Matrice);

    //Position des Blocs Pieges dans la matrice
    PositionBlocPiegesNiv3(Matrice);

    //Position des Blocs VIE dans la matrice
    PositionBlocVieNiv3(Matrice);


    //Coordonnées de Snoopy
    int snoopyX, snoopyY;

    // Placer Snoopy  dans une case aleatoire où il n'a pas ni oiseaux ni blocs(cassable,Poussable,Pieges)
    do {
        snoopyX = rand() % colonnes;
        snoopyY = rand() % lignes;
    } while (Matrice[snoopyY][snoopyX] == OISEAU || Matrice[snoopyY][snoopyX] == POUSSABLE ||
             Matrice[snoopyY][snoopyX] == CASSABLE || Matrice[snoopyX][snoopyY] == PIEGE);

    // Position initiale de Snoopy
    Matrice[snoopyY][snoopyX] = SNOOPY;

    // Afficher la balle dans la matrice
    Matrice[balleY][balleX] = BALLE;

    // Initialisation du temps de début
    time_t tempsDebut = time(NULL);

    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {

        Color(11, 0);
        printf("\n\n\tVies restante : %d\n\n",viesSnoopy);

        // Obtenez le temps actuel
        time_t tempsActuel = time(NULL);

        // Calculez le temps écoulé en secondes
        int tempsEcoule = tempsActuel - tempsDebut;

        // Votre boucle principale du jeu ici

        // Affichez le temps restant
        printf("\n\n\tTemps restant : %d secondes\n", TEMPS - tempsEcoule);

        // Ajoutez une pause d'une seconde entre chaque itération
        sleep((unsigned int) 0.2);

        char action;
        printf("\n\n");
        AffichageMatrice(Matrice);

        Color(5, 0);
        printf("\n\n Les actions possibles :\n\t h -> haut \t b ->bas \t g -> gauche \t d -> droite \t p -> pause \t c -> changer de niveau :\n");

        Color(15, 0);//violet
        // Demande à l'utilisateur de saisir une action spécifique
        printf("\n\nEntrez une action (h, b, g, d, p, c) : \n");
        // Utilisation de getch() pour lire une seule touche
        action = getch();

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if ((action == 'h'|| action == 'H') && snoopyY > 0) {
            system("cls");
            CoordonneeYCase = snoopyY - 1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;

        } else if ((action =='b' || action == 'B') && snoopyY < lignes - 1) {
            system("cls");
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY + 1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;

        } else if ((action == 'g'|| action == 'G') && snoopyX > 0) {
            system("cls");
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;

        } else if ((action== 'd'|| action == 'D') && snoopyX < colonnes - 1) {
            system("cls");
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;

        } else if (action == 'p'|| action == 'P' ) {
            system("cls");
            int choice;
            printf("\nVous etes en pause\n\n");
            printf("\t1- reprendre le jeu\n");
            printf("\t2- Sauvegarder la partie et quitter\n");
            printf("\t3- Quitter");
            printf("\n\nEntrer votre choix :\n");
            choice = getch();
            choice = atoi(&choice);
            switch (choice) {
                case 1 :
                    printf("\n\nPause finie ...\n");
                    break;
                case 2 :
                    sauvegarderPartie3(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,Matrice);
                    return;
                case 3 :
                    printf("Au revoir ! ");
                default:
                    printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3 ! \n");
                    printf("Choix : \n");
                    choice = getch();
            }
        }
        else if (action == 'c'|| action == 'C' ) {
            char choix;
            char mdp[10];

            do {

                printf("\nVous voulez passer a un autre niveau :\n");
                printf("\nChoisissez le niveau auquel vous voulez aller :\n");
                printf("\n Menu Niveaux : \n\n");
                printf("\t\t 1 - Niveau 1\n\n");
                printf("\t\t 2 - Niveau 2\n\n");

                choix = getch();
                choix = atoi(&choix);

                if (choix != 1 && choix != 2) {
                    system("cls");
                    printf("Choix invalide. Veuillez choisir 1 ou 2.\n");
                }

            } while (choix != 1 && choix != 2);  // Continuer à demander le choix tant qu'il n'est pas 2 ou 3

            switch (choix) {
                case 1:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau1\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau1\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau1Menu(choix);
                    break;

                case 2:
                    printf("\nVous souhaitez passer au Niveau %d :\n", choix);
                    do {
                        printf("\nEntrer votre mot de passe: \n");
                        fgets(mdp, 10, stdin);
                        // Si le mot de passe est incorrect, afficher un message d'erreur
                        if (strcmp(mdp, "niveau2\n") != 0) {
                            printf("\nLe mot de passe saisi est incorrect, veuillez réessayer :\n");
                        }
                        // Continuer à demander le mot de passe tant qu'il est incorrect
                    } while (strcmp(mdp, "niveau2\n") != 0);

                    // Le mot de passe saisi est correct
                    niveau2Menu(choix);
                    break;

            }
        }
        else {
            Color(4, 0); //rouge
            printf("\n\nAttention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            Color(11, 0);
            printf("\n\nFelicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);

        } else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
        // Appeler la fonction pour gérer la balle
        bougerBalle(Matrice, &balleX, &balleY, &directionBalle, &viesSnoopy, snoopyX, snoopyY);

        // Ajoutez une condition pour vérifier si le temps est écoulé
        if (tempsEcoule >= TEMPS) {
            printf("\n\nLe temps est ecoule. Vous avez perdu une vie.\n");
            viesSnoopy--;

            // Réinitialisez le temps de début
            tempsDebut = time(NULL);
        }

    }

    // Vérification s'il reste encore des oiseaux à collecter ou si Snoopy possède encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
        Color(11, 0);
        printf("\n\n Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else if (viesSnoopy == 0) {
        Color(4, 0);
        printf("\t\tSnoopy n'a plus de vies. \n\tVous avez perdu\n");
        sleep(2);
        Color(15, 0);
        MenuPrincipale();
    }


}


void chargerPartie1(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle,int *secondesRestantes, char matrice[lignes][colonnes]) {
    FILE *fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie1.txt", "r");
    if (fichierSauvegarde != NULL) {
        fscanf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d\n%d", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle,secondesRestantes);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fscanf(fichierSauvegarde, " %c", &matrice[i][j]);
            }
        }
        fclose(fichierSauvegarde);
    } else {
        printf("\n Aucune sauvegarde trouvee.\n");
    }
}
void chargerPartie2(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]) {
    FILE *fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie2.txt", "r");
    if (fichierSauvegarde != NULL) {
        fscanf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fscanf(fichierSauvegarde, " %c", &matrice[i][j]);
            }
        }
        fclose(fichierSauvegarde);
    } else {
        printf("\n Aucune sauvegarde trouvee.\n");
    }
}
void chargerPartie3(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]) {
    FILE *fichierSauvegarde = fopen("C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie3.txt", "r");
    if (fichierSauvegarde != NULL) {
        fscanf(fichierSauvegarde, "%d\n%d\n%d\n%d\n%d\n%d\n%d", viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX, balleY, directionBalle);
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                fscanf(fichierSauvegarde, " %c", &matrice[i][j]);
            }
        }
        fclose(fichierSauvegarde);
    } else {
        printf("\n Aucune sauvegarde trouvee.\n");
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////// Menu du jeu ////////////////////////////////////////////////////////////////////////////////////////////////////////////


// prototype de la focntion Menuprincipale
void MenuPrincipale();


void niveau1Menu(int niveauChoisi) {
    system("cls");
    int choix = 0;
    char choixchar;
    int viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX,balleY,directionBalle,secondesRestantes, secondes;
    char Matrice[lignes][colonnes];
    while (choix != 3) {
        printf("\nvous etes en Niveau %d : \n\n", niveauChoisi);
        printf("\t 1 - Reprendre une partie sauvegardee\n\n");
        printf("\t\t2 - Nouvelle partie\n\n");
        printf("\t\t\t3 - Retour au menu principal\n\n");
        printf("`\n  Choix : \n");
        choixchar = getch();
        choix = atoi(&choixchar);

        switch (choix) {
            case 1:
                system("cls");
                // Reprendre une partie sauvegardée pour le niveau choisi
                chargerPartie1(&viesSnoopy,&oiseauxRestants, &snoopyX, &snoopyY, &balleX, &balleY, &directionBalle,&secondesRestantes, Matrice);
                printf("chargement du fichier \" C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie1.txt\" en cours ...\n");
                niveau1charger(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,secondes,Matrice);
                break;
            case 2:
                system("cls");
                // Démarrer une nouvelle partie pour le niveau choisi
                niveau1Initiale();

                return;
            case 3:
                system("cls");
                //retour au menu pricipale par l'appel de la fonction MenuPrincipale
                MenuPrincipale();
                return;
            default:
                Color(4, 0);
                printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3.\n");
        }
    }
}

void niveau2Menu(int niveauChoisi) {
    system("cls");
    int choix = 0;
    char choixchar;
    int viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX,balleY,directionBalle;
    char Matrice[lignes][colonnes];
    while (choix != 3) {
        printf("\nvous etes en Niveau %d : \n\n", niveauChoisi);
        printf("\t 1 - Reprendre une partie sauvegardee\n\n");
        printf("\t\t2 - Nouvelle partie\n\n");
        printf("\t\t\t3 - Retour au menu principal\n\n");
        printf("`\n  Choix : \n");
        choixchar = getch();
        choix = atoi(&choixchar);

        switch (choix) {
            case 1:
                system("cls");
                // Reprendre une partie sauvegardée pour le niveau choisi
                chargerPartie2(&viesSnoopy,&oiseauxRestants, &snoopyX, &snoopyY, &balleX, &balleY, &directionBalle, Matrice);
                printf("chargement du fichier \" C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie2.txt\" en cours ...\n");
                niveau2charger(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,  Matrice);
                break;
            case 2:
                system("cls");
                // Démarrer une nouvelle partie pour le niveau choisi
                niveau2Initiale();
                return;
            case 3:
                system("cls");
                //retour au menu pricipale par l'appel de la fonction MenuPrincipale
                MenuPrincipale();
                return;
            default:
                Color(4, 0);
                printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3.\n");
        }
    }
}
void niveau3Menu(int niveauChoisi) {
    system("cls");
    int choix = 0;
    char choixchar;
    int viesSnoopy, oiseauxRestants, snoopyX, snoopyY,balleX,balleY,directionBalle;
    char Matrice[lignes][colonnes];
    while (choix != 3) {
        printf("\nvous etes en Niveau %d : \n\n", niveauChoisi);
        printf("\t 1 - Reprendre une partie sauvegardee\n\n");
        printf("\t\t2 - Nouvelle partie\n\n");
        printf("\t\t\t3 - Retour au menu principal\n\n");
        printf("`\n  Choix : \n");
        choixchar = getch();
        choix = atoi(&choixchar);


        switch (choix) {
            case 1:
                // Reprendre une partie sauvegardée pour le niveau choisi
                chargerPartie3(&viesSnoopy,&oiseauxRestants, &snoopyX, &snoopyY, &balleX, &balleY, &directionBalle, Matrice);
                printf("chargement du fichier \" C:\\Users\\oulag\\CLionProjects\\sauvegarde_partie3.txt\" en cours ...\n");
                niveau3charger(viesSnoopy, oiseauxRestants, snoopyX, snoopyY, balleX, balleY, directionBalle,  Matrice);

                break;
            case 2:
                // Démarrer une nouvelle partie pour le niveau choisi
                niveau3Initiale();
                exit(0);
            case 3:
                //retour au menu pricipale par l'appel de la fonction MenuPrincipale
                MenuPrincipale();
                break;
            default:
                Color(4, 0);
                printf("Choix invalide. Veuillez choisir parmi 1, 2 ou 3.\n");
        }
    }
}

void sousMenuNiveaux() {
    system("cls");
    int choixNiveau = 0;
    char choixNiveauChar;
    while (choixNiveau != 3) {
        printf("\n Menu Niveaux : \n\n");
        printf("\t 1 - Niveau 1\n\n");
        printf("\t\t 2 - Niveau 2\n\n");
        printf("\t\t\t 3 - Niveau 3\n\n");
        printf("\t\t\t\t 4 - Retour au menu principale\n");
        printf("\n  Choix : \n");
        choixNiveauChar = getch();
        // Convertir le caractère en entier
        choixNiveau = atoi(&choixNiveauChar);

        switch (choixNiveau) {
            case 1:
                niveau1Menu(choixNiveau);
                break;
            case 2:
                niveau2Menu(choixNiveau);
                break;
            case 3:
                niveau3Menu(choixNiveau);
                break;
            case 4:
                break;
            default:
                printf("Choix invalide. Veuillez choisir un niveau de 1 a 4.\n");

        }
    }
}

void MenuRegles(){

    system("cls");
    char acte;
    int choix ;
    printf("\n\n Regles du jeu :\n\n");
    printf("\t - Vous disposez de 3 vies.\n\n");
    printf("\t - Recuperez les 4 oiseaux en moins de 120 secondes.\n\n");
    printf("\t - Un bloc poussable ('P') est pousse une seule fois.\n\n");
    printf("\t - Ne pas toucher un bloc piege ('K') sous peine de perdre une vie.\n\n");
    printf("\t - Tout depassement de 120 secondes entraine automatiquement une perte de vie.\n\n");
    printf("\t - Le jeu se termine si le nombre de vies atteint 0.\n\n");

    printf("\n Voulez-vous revenir au menu principal ? :\n");
    printf("\n 1 - Retour  \t 2 - Quitter \n");
    acte = getch();
    choix = atoi(&acte);
    switch (choix) {
        case 1:
            MenuPrincipale();
            break;
        case 2:

            system("cls");

            break;

    }
}



void MenuPrincipale() {
    system("cls");
    int choix = 0;
    char choixchar;
    while (choix != 2) {
        printf("\n Menu Principal :\n\n");
        printf("\t 1 - Regles du jeu\n ");
        printf("\n\n\t 2 - Jouer\n");
        printf("\n\n\t 3- Quitter\n");
        printf("\n\n  Choix : \n");
        choixchar = getch();
        choix = atoi(&choixchar);

        switch (choix) {
            case 1:
                MenuRegles();
                break;
            case 2:
                sousMenuNiveaux();
                break;
            case 3:
                printf("\nAu revoir!\n");
                break;
            default:
                printf("\nChoix invalide. Veuillez choisir 1 ou 2.\n");
        }
    }
}