/* Timer de 180 secondes
 * Chaque 60 secondes Snoopy perd 1 vie
 * Source : https://www.youtube.com/watch?v=dG1HBSArgjM
 * https://github.com/portfoliocourses/c-example-code/blob/main/countdown_timer.c
 * */



#include <stdio.h>
#include <unistd.h>

#define ROWS 10
#define COLS 20

// Fonction pour afficher le temps restant en haut à droite de la matrice
void afficherTempsRestant(int minutes, int secondes) {
    printf("\033[%d;%dHTemps restant : %02d:%02d\n", 1, COLS * 4- 9, minutes, secondes);
}
void afficherVie(int vies) {
    printf("Vous avez perdu une vie ! Vies restantes : %d\n", vies);
    // Afficher le message de perte de vie}

}

int main() {
    // Durée du minuteur (par exemple, 5 minutes)
    int minutes = 3;
    int secondes = 0;
    int vies = 3;

    // Convertir le temps total en secondes
    int tempsTotalEnSecondes = minutes * 60 + secondes;

    // Boucle du minuteur
    while (tempsTotalEnSecondes > 0) {
        // Afficher le temps restant en haut à droite
        afficherTempsRestant(tempsTotalEnSecondes / 60, tempsTotalEnSecondes % 60);

        // Attendre une seconde
        sleep(1);

        // Décrémenter le temps restant
        tempsTotalEnSecondes--;
    }
    // Vérifier si une minute s'est écoulée
    if (tempsTotalEnSecondes % 60 == 0) {
        // Perdre une vie chaque minute
        vies--;
        afficherVie(vies);



        // Le minuteur a expiré
        printf("Le minuteur a expiré !\n");
        return 0;
    }
}
