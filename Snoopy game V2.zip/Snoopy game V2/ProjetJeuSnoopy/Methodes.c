#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//Dimensions de la matrice
#define lignes 10
#define colonnes 20

//Définition des élements de la matrice en macros
#define SNOOPY 'S'
#define OISEAU 'O'
#define POUSSABLE 'P'
#define CASSABLE 'C'
#define PIEGE 'K'
#define BALLE 'X'

// Définition des constantes pour les directions de la balle
#define DIRECTION_HAUT_GAUCHE 1
#define DIRECTION_HAUT_DROITE 2
#define DIRECTION_BAS_GAUCHE 3
#define DIRECTION_BAS_DROITE 4

// Fonction pour initialiser la matrice
void initialiserMatrice(char matrice[lignes][colonnes]) {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            matrice[i][j] = '.';
        }
    }

}

//fonctions de placement des élements dans la matrice
void PositionOiseaux(char matrice[lignes][colonnes]){
    // Placement des oiseaux dans les coins de la matrice avec la symbol 'O' stocké dans OISEAU
    matrice[0][0] = OISEAU;
    matrice[0][colonnes - 1] = OISEAU;
    matrice[lignes - 1][0] = OISEAU;
    matrice[lignes - 1][colonnes - 1] = OISEAU;
}
void PositionBlocPoussable(char matrice[lignes][colonnes]){
    // Placement de 3 blocs poussables (stocké dans POUSSABLE en macros)
    matrice[7][17] = POUSSABLE;
    matrice[3][13] = POUSSABLE;
    matrice[2][3] = POUSSABLE;
    matrice[5][5] = POUSSABLE;
}

void PositionBlocCassable(char matrice[lignes][colonnes]){
    // Placement de 3 blocs cassables (stocké dans CASSABLE en macros)
    matrice[6][19] = CASSABLE;
    matrice[4][0] = CASSABLE;
    matrice[1][10] = CASSABLE;
    matrice[9][6] = CASSABLE;
}

void PositionBlocPieges(char matrice[lignes][colonnes]){
    // Placement de 3 blocs pieges (stocké dans PIEGE en macros)
    matrice[0][2] = PIEGE;
    matrice[7][4] = PIEGE;
    matrice[1][18] = PIEGE;
    matrice[9][18] = PIEGE;
    matrice[6][9] = PIEGE;
}

//fonction d'affichage de la matrice
void AffichageMatrice(char matrice[lignes][colonnes]){
    // Affichage de la matrice
    for (int i = 0; i < lignes; i++) {
        for (int j = 0; j < colonnes; j++) {
            printf("%c ", matrice[i][j]);
        }
        printf("\n");
    }
}

// Fonction pour casser un bloc cassable
void casserBloc(char matrice[10][20], int coordonneeX, int coordonneeY) {
    char acte[10];
    do {
        printf("\nEntrez \"casser\" pour casser le bloc : ");

        scanf("%s", acte);

        // Vérifiez si l'action saisi est correcte pour casser le bloc
        if (strcmp(acte, "casser") != 0) {
            printf("\nAction incorrecte. Entrez 'casser' pour casser le bloc.\n");
        }
    } while (strcmp(acte, "casser") != 0);
    printf("\nBravo ! Vous avez reussi a casser le bloc\n");
}


// Fonction pour pousser un bloc poussable
void pousserBloc(char matrice[10][20], int coordonneeX, int coordonneeY, int a) {
    char action[10];
    do {
        printf("\nEntrez \"pousser\" pour pousser le bloc :\n ");
        scanf("%s", action);

        // Vérifiez si l'action saisi est correcte pour casser le bloc
        if (strcmp(action, "pousser") != 0) {
            printf("\nAction incorrecte. Entrez 'pousser' pour pousser le bloc.\n");
        }
    } while (strcmp(action, "pousser") != 0);

    printf("\nBravo ! Vous avez reussi a pousser le bloc\n");
}

// Définition de la structure CoordonneesEtVies comme type de retour des fonctions suivantes
typedef struct {
    int coordonneeX;
    int coordonneeY;
    int vies;
} CoordonneesEtVies;

// Fonction de vérification si le pas suivant de snoopy en Haut correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc(matrice,coordonneeX,coordonneeY);
        //Snoopy se deplace en haut
        coordonneeY--;
    } else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        pousserBloc(matrice,coordonneeX,coordonneeY,a);
        //Remplacer la case suivante par Poussable 'P'
        matrice[a-1][coordonneeX] = POUSSABLE;
        //Snoopy se deplace en haut
        coordonneeY--;
    } else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n ");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n ");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeY--;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy en Bas correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc(matrice,coordonneeX,coordonneeY);
        //Snoopy se deplace en haut
        coordonneeY++;
    } else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        pousserBloc(matrice,coordonneeX,coordonneeY,a);
        //Remplacer la case a+1 par P
        matrice[a+1][coordonneeX] = POUSSABLE;
        //Snoopy se deplace en haut
        coordonneeY++;
    } else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n ");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n ");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeY++;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy à gauche correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies) {
    CoordonneesEtVies resultat;

    if (matrice[coordonneeY][a] == CASSABLE) {
        printf("il y'a un bloc cassable\n");
        casserBloc(matrice,coordonneeX,coordonneeY);
        coordonneeX--;
    } else if (matrice[coordonneeY][a] == POUSSABLE) {
        printf("il y'a un bloc POUSSABLE\n");
        pousserBloc(matrice,coordonneeX,coordonneeY,a);
        //Remplacer la case a-1 par P
        matrice[coordonneeY][a-1] = POUSSABLE;
        //Deplacer Snoopy
        coordonneeX--;
    } else if (matrice[coordonneeY][a] == PIEGE) {
        printf("il y'a un bloc PIEGE\n");
        coordonneeX = coordonneeX;
        vies--;
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n");
        printf("Nombre de vies restantes = %d\n", vies);
    } else {
        coordonneeX--;
    }

    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy à Droite correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[coordonneeY][a] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        casserBloc(matrice,coordonneeX,coordonneeY);
        //Snoopy se deplace à droite
        coordonneeX++;
    } else if(matrice[coordonneeY][a] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        pousserBloc(matrice,coordonneeX,coordonneeY,a);
        //Remplacer la case a+1 par P
        matrice[coordonneeY][a+1] = POUSSABLE;
        //Snoopy se deplace à droite
        coordonneeX++;
    } else if(matrice[coordonneeY][a] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeX = coordonneeX;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeX++;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction pour gérer la balle
void bougerBalle(char matrice[lignes][colonnes], int *balleX, int *balleY, int *directionBalle, int *viesSnoopy, int snoopyX, int snoopyY) {
    // Sauvegarder les anciennes coordonnées de la balle
    int ancienneX = *balleX;
    int ancienneY = *balleY;


    // Mettre à jour la position de la balle en diagonale
    if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
        (*balleX)--;
        (*balleY)--;
    } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
        (*balleX)++;
        (*balleY)--;
    } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
        (*balleX)--;
        (*balleY)++;
    } else if (*directionBalle == DIRECTION_BAS_DROITE) {
        (*balleX)++;
        (*balleY)++;
    }

    // Vérifier les rebonds sur les murs
    if (*balleX < 0 || *balleX >= colonnes) {
        // Inverser la direction horizontale
        if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
            *directionBalle = DIRECTION_HAUT_DROITE;
        } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
            *directionBalle = DIRECTION_BAS_DROITE;
        } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
            *directionBalle = DIRECTION_HAUT_GAUCHE;
        } else if (*directionBalle == DIRECTION_BAS_DROITE) {
            *directionBalle = DIRECTION_BAS_GAUCHE;
        }
    }

    if (*balleY < 0 || *balleY >= lignes) {
        // Inverser la direction verticale
        if (*directionBalle == DIRECTION_HAUT_GAUCHE) {
            *directionBalle = DIRECTION_BAS_GAUCHE;
        } else if (*directionBalle == DIRECTION_HAUT_DROITE) {
            *directionBalle = DIRECTION_BAS_DROITE;
        } else if (*directionBalle == DIRECTION_BAS_GAUCHE) {
            *directionBalle = DIRECTION_HAUT_GAUCHE;
        } else if (*directionBalle == DIRECTION_BAS_DROITE) {
            *directionBalle = DIRECTION_HAUT_DROITE;
        }
    }

    // Vérifier si la balle touche Snoopy
    if (*balleX == snoopyX && *balleY == snoopyY) {
        (*viesSnoopy)--;
        printf("La balle a touché Snoopy ! Vies restantes : %d\n", *viesSnoopy);
        // Remettre Snoopy à sa position initiale
        matrice[snoopyY][snoopyX] = '.';
        // Placer Snoopy dans une nouvelle position aléatoire
        do {
            snoopyX = rand() % colonnes;
            snoopyY = rand() % lignes;
        } while (matrice[snoopyY][snoopyX] == OISEAU || matrice[snoopyY][snoopyX] == POUSSABLE || matrice[snoopyY][snoopyX] == CASSABLE || matrice[snoopyX][snoopyY] == PIEGE);

        matrice[snoopyY][snoopyX] = SNOOPY;
    }


    // Remplacer l'ancienne position par un point ('.') pour indiquer que la case est vide
    matrice[ancienneY][ancienneX] = '.';

    // Afficher la balle dans la matrice
    matrice[*balleY][*balleX] = BALLE;
}

