//
// Created by oulag on 28/10/2023.
//

//Dimensions de la matrice
#define lignes 10
#define colonnes 20

#ifndef PROJETJEUSNOOPY_BIBLIOTHEQUES_H
#define PROJETJEUSNOOPY_BIBLIOTHEQUES_H
// fonction qui gere les couleurs
void Color(int couleurDuTexte,int couleurDeFond);

// entête de la fonction d'initialisation de la matrice
void initialiserMatrice(char matrice[lignes][colonnes]);

// entêtes des fonctions de placement des elements dans de la matrice
void PositionOiseaux(char matrice[lignes][colonnes]);
void PositionBlocPoussable(char matrice[lignes][colonnes]);
void PositionBlocCassable(char matrice[lignes][colonnes]);
void PositionBlocPiegesNiv1(char matrice[lignes][colonnes]);
void PositionBlocPiegesNiv2(char matrice[lignes][colonnes]);
void PositionBlocPiegesNiv3(char matrice[lignes][colonnes]);

// entête de la fonction d'affichage de contenu de la matrice
void AffichageMatrice(char matrice[lignes][colonnes]);

// la stucture CoordonneeEtVies
        typedef struct {
            int coordonneeX;
            int coordonneeY;
            int vies;

        } CoordonneesEtVies;

//entête de la fonction de vérification en Haut
CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);

//entête de la fonction de vérification en Bas
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);

//entête de la fonction de vérification à Gauche
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies);

//entête de la fonction de vérification à Droite
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);

// Fonction pour casser un bloc cassable
void casserBloc();

// Fonction pour bouger la balle
void bougerBalle(char matrice[lignes][colonnes], int *balleX, int *balleY, int *directionBalle, int *viesSnoopy, int snoopyX, int snoopyY);

//Niveau 1 sauvegarde et chargement :

///prototype de la fonction sauvegrade ///
void sauvegarderPartie1(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX,int balleY,int directionBalle, char matrice[lignes][colonnes]);

///prototype de la fonction chargement ///
void chargerPartie1(int *viesSnoopy, int *oiseauxRestants, int *snoopyX, int *snoopyY, int *balleX, int *balleY, int *directionBalle, char matrice[lignes][colonnes]);

//Menu des niveau
void niveau1Menu(int niveauChoisi);

void niveau2Menu(int niveauChoisi);
void niveau3Menu(int niveauChoisi);










//////////// fonction principale de niveau 1 //////////

void niveau1charger(int viesSnoopy, int oiseauxRestants, int snoopyX, int snoopyY,int balleX, int balleY,int directionBalle, char Matrice[lignes][colonnes]);

void niveau1Initiale();

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////// Menu du jeu ///////////////////////////////////////////////////////////////////////////////////////////////////////////
void MenuPrincipale();
void niveauxMenu(int niveauChoisi);
void sousMenuNiveaux();

#endif //PROJETJEUSNOOPY_BIBLIOTHEQUES_H
