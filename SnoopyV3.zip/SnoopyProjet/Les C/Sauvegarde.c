//
// Created by Oumarou Dramé on 12/11/2023.
//

#include <stdlib.h>
#include <stdio.h>
#include "../Les H/StructureSnoopy.h"
#include "../Les H/StructureOiseau.h"
#include "../Les H/StructureBlocPoussable.h"
#include "../Les H/StructureBlocCassable.h"

void Sauvegarde(Snoopy* snoopy, BlocPoussable* blocPoussable1, BlocPoussable* blocPoussable2, BlocCassable* blocCassable1, Oiseau* oiseau1,Oiseau* oiseau2, Oiseau* oiseau3, Oiseau* oiseau4)
{

    FILE* fichier = NULL;

    fichier = fopen("Sauvegarde.txt","w+");
    int inexistant = 99;

    if (fichier != NULL)
    {
        fprintf(fichier,"%d ", snoopy->positionLigne);
        fprintf(fichier,"%d ", snoopy->positionColonne);
        fprintf(fichier,"%d ", snoopy->nombreDeVie);

        fprintf(fichier,"%d ", blocPoussable1->positionLigne);
        fprintf(fichier,"%d ", blocPoussable1->positionColonne);
        fprintf(fichier,"%d ", blocPoussable1->poussable);
        fprintf(fichier,"%d ", blocPoussable2->positionLigne);
        fprintf(fichier,"%d ", blocPoussable2->positionColonne);
        fprintf(fichier,"%d ", blocPoussable2->poussable);

        if (blocCassable1->casse > 0)
        {
            fprintf(fichier,"%d ", blocCassable1->positionLigne);
            fprintf(fichier,"%d ", blocCassable1->positionColonne);
            fprintf(fichier,"%d ", blocCassable1->casse);
        }
        else{
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", blocCassable1->casse);
        }
        if (oiseau1->nombreOiseau > 0)
        {
            fprintf(fichier,"%d ", oiseau1->positionLigne);
            fprintf(fichier,"%d ", oiseau1->positionColonne);
            fprintf(fichier,"%d ", oiseau1->nombreOiseau);
        }
        else{
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", oiseau1->nombreOiseau);
        }
        if (oiseau2->nombreOiseau > 0)
        {
            fprintf(fichier,"%d ", oiseau2->positionLigne);
            fprintf(fichier,"%d ", oiseau2->positionColonne);
            fprintf(fichier,"%d ", oiseau2->nombreOiseau);
        }
        else{
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", oiseau2->nombreOiseau);
        }
        if (oiseau3->nombreOiseau > 0)
        {
            fprintf(fichier,"%d ", oiseau3->positionLigne);
            fprintf(fichier,"%d ", oiseau3->positionColonne);
            fprintf(fichier,"%d ", oiseau3->nombreOiseau);
        }
        else{
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", oiseau3->nombreOiseau);
        }
        if (oiseau4->nombreOiseau > 0)
        {
            fprintf(fichier,"%d ", oiseau4->positionLigne);
            fprintf(fichier,"%d ", oiseau4->positionColonne);
            fprintf(fichier,"%d", oiseau4->nombreOiseau);
        }
        else{
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d ", inexistant);
            fprintf(fichier,"%d", oiseau4->nombreOiseau);
        }

        fclose(fichier);
    }
    else
    {
        printf("Impossible d'ouvrir le fichier test.txt");
    }
}