//
// Created by Oumarou Dramé on 12/11/2023.
//

#include "../Les H/StructureBalle.h"
#include "../Les H/DimmensionMatrice.h"

void BalleDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Balle* balle)
{
    matrice[balle->positionLigne][balle->positionColonne] = 7;
}
