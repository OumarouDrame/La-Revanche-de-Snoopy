//
// Created by Oumarou Dramé on 12/11/2023.
//

#include <stdio.h>
#include <stdlib.h>
#include "../Les H/StructureSnoopy.h"
#include "../Les H/StructureOiseau.h"
#include "../Les H/StructureBlocPoussable.h"
#include "../Les H/StructureBlocCassable.h"
#include "../Les H/DimmensionMatrice.h"



void DeplacementSnoopy(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Snoopy* snoopy, BlocPoussable* blocPoussable1, BlocPoussable* blocPoussable2, BlocCassable* blocCassable1, Oiseau* oiseau1,Oiseau* oiseau2, Oiseau* oiseau3, Oiseau* oiseau4) {


    int deplacement;
    int decision;

    int anciennePositionLigneSnoopy = snoopy->positionLigne;
    int anciennePositionColonneSnoopy = snoopy->positionColonne;
    int anciennePositionLigneBlocPoussable1 = blocPoussable1->positionLigne;
    int anciennePositionColonneBlocPoussable1 = blocPoussable1->positionColonne;
    int anciennePositionLigneBlocPoussable2 = blocPoussable2->positionLigne;
    int anciennePositionColonneBlocPoussable2 = blocPoussable2->positionColonne;

    int compteurOiseau;

    printf("Fais bouger Snoopy :\n8 (Haut); 5 (Bas); 6 (Droite); 4 (Gauche)\n");

    scanf("%d", &deplacement);

    switch (deplacement) {
        case 8: // Haut
            (snoopy->positionLigne)--;
            break;
        case 5: // Bas
            (snoopy->positionLigne)++;
            break;
        case 4: // Gauche
            (snoopy->positionColonne)--;
            break;
        case 6: // Droite
            (snoopy->positionColonne)++;
            break;
        default:
            printf("Mouvement invalide\n");
            return;
    }

    if (matrice[snoopy->positionLigne][snoopy->positionColonne] == 9) {

        if (snoopy->positionLigne == 0 && snoopy->positionColonne == 0) {

            oiseau1->nombreOiseau--;
            compteurOiseau = oiseau1->nombreOiseau + oiseau2->nombreOiseau + oiseau3->nombreOiseau + oiseau4->nombreOiseau;

            if (compteurOiseau>0)
            {
                printf("Bravo, il ne te reste plus que %d oiseaux a recuperer !\n", compteurOiseau);
            } else
            {
                printf("Felicitation, tous les oiseaux ont ete recuperes.\nSnoppy a gagne !");
                exit(0);
            }
        }
        if (snoopy->positionLigne == 0 && snoopy->positionColonne == NOMBRECOLONNE-1) {

            oiseau2->nombreOiseau--;
            compteurOiseau = oiseau1->nombreOiseau + oiseau2->nombreOiseau + oiseau3->nombreOiseau + oiseau4->nombreOiseau;

            if (compteurOiseau>0)
            {
                printf("Bravo, il ne te reste plus que %d oiseaux a recuperer !\n", compteurOiseau);
            } else
            {
                printf("Felicitation, tous les oiseaux ont ete recuperes.\nSnoppy a gagne !");
                exit(0);
            }
        }
        if (snoopy->positionLigne == NOMBRELIGNE-1 && snoopy->positionColonne == 0) {

            oiseau3->nombreOiseau--;
            compteurOiseau = oiseau1->nombreOiseau + oiseau2->nombreOiseau + oiseau3->nombreOiseau + oiseau4->nombreOiseau;

            if (compteurOiseau>0)
            {
                printf("Bravo, il ne te reste plus que %d oiseaux a recuperer !\n", compteurOiseau);
            } else
            {
                printf("Felicitation, tous les oiseaux ont ete recuperes.\nSnoppy a gagne !");
                exit(0);
            }
        }
        if (snoopy->positionLigne == NOMBRELIGNE-1 && snoopy->positionColonne == NOMBRECOLONNE-1) {

            oiseau4->nombreOiseau--;
            compteurOiseau = oiseau1->nombreOiseau + oiseau2->nombreOiseau + oiseau3->nombreOiseau + oiseau4->nombreOiseau;

            if (compteurOiseau>0)
            {
                printf("Bravo, il ne te reste plus que %d oiseau a recuperer !\n", compteurOiseau);
            } else
            {
                printf("Felicitation, tous les oiseaux ont ete recuperes.\nSnoppy a gagne !");
                exit(0);
            }
        }
    }

    if (matrice[snoopy->positionLigne][snoopy->positionColonne] == 3) {

        snoopy->nombreDeVie--;

        if(snoopy->nombreDeVie > 0)
        {
            printf("Snoopy vient de perdre une vie !\nSnoopy n'a plus que %d vies.\n", snoopy->nombreDeVie);
        }
        else
        {
            printf("Snoopy n'a plus de vie. Fin du jeu.\n");
            exit(0);
        }
    }

    if (matrice[snoopy->positionLigne][snoopy->positionColonne] == 2) {
        printf("Un bloc poussable ! Touche 7 pour le pousser sinon touche 9\n");
        scanf("%d", &decision);

        switch (decision) {
            case 7: // Bloc poussé
                if (snoopy->positionLigne == blocPoussable1->positionLigne) {
                    if (deplacement == 8) {
                        if (blocPoussable1->poussable != 0) {
                            (blocPoussable1->positionLigne)--;
                            (snoopy->positionLigne)++;
                            (blocPoussable1->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable1][anciennePositionColonneBlocPoussable1] = 0;
                            printf("Le Bloc a ete pousse le haut\n");
                        } else {
                            (snoopy->positionLigne)++;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    } else if (deplacement == 5) {
                        if (blocPoussable1->poussable != 0) {
                            (blocPoussable1->positionLigne)++;
                            (snoopy->positionLigne)--;
                            (blocPoussable1->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable1][anciennePositionColonneBlocPoussable1] = 0;
                            printf("Le Bloc a ete pousse vers le bas\n");
                        } else {
                            (snoopy->positionLigne)--;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    } else if (deplacement == 4) {
                        if (blocPoussable1->poussable != 0) {
                            (blocPoussable1->positionColonne)--;
                            (snoopy->positionColonne)++;
                            (blocPoussable1->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable1][anciennePositionColonneBlocPoussable1] = 0;
                            printf("Le Bloc a ete pousse vers la gauche\n");
                        } else {
                            (snoopy->positionColonne)++;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    } else if (deplacement == 6) {
                        if (blocPoussable1->poussable != 0) {
                            (blocPoussable1->positionColonne)++;
                            (snoopy->positionColonne)--;
                            matrice[anciennePositionLigneBlocPoussable1][anciennePositionColonneBlocPoussable1] = 0;
                            printf("Le Bloc a ete pousse vers la droite\n");
                        } else {
                            (snoopy->positionColonne)--;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    }
                }

                else if (snoopy->positionLigne == blocPoussable2->positionLigne) {
                    if (deplacement == 8) {
                        if (blocPoussable2->poussable != 0) {
                            (blocPoussable2->positionLigne)--;
                            (snoopy->positionLigne)++;
                            (blocPoussable2->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable2][anciennePositionColonneBlocPoussable2] = 0;
                            printf("Le Bloc a ete pousse le haut\n");
                        } else {
                            (snoopy->positionLigne)++;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    } else if (deplacement == 5) {
                        if (blocPoussable2->poussable != 0) {
                            (blocPoussable2->positionLigne)++;
                            (snoopy->positionLigne)--;
                            (blocPoussable2->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable2][anciennePositionColonneBlocPoussable2] = 0;
                            printf("Le Bloc a ete pousse vers le bas\n");
                        } else {
                            (snoopy->positionLigne)--;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    } else if (deplacement == 4) {
                        if (blocPoussable2->poussable != 0) {
                            (blocPoussable2->positionColonne)--;
                            (snoopy->positionColonne)++;
                            (blocPoussable2->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable2][anciennePositionColonneBlocPoussable2] = 0;
                            printf("Le Bloc a ete pousse vers la gauche\n");
                        } else {
                            (snoopy->positionColonne)++;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    } else if (deplacement == 6) {
                        if (blocPoussable2->poussable != 0) {
                            (blocPoussable2->positionColonne)++;
                            (snoopy->positionColonne)--;
                            (blocPoussable2->poussable)--;
                            matrice[anciennePositionLigneBlocPoussable2][anciennePositionColonneBlocPoussable2] = 0;
                            printf("Le Bloc a ete pousse vers la droite\n");
                        } else {
                            (snoopy->positionColonne)--;
                            printf("Ce bloc a deja ete pousse\n");
                        }
                    }
                }
                break;
            case 9: // Bloc pas poussé
                if (deplacement == 8) {
                    (snoopy->positionLigne)++;
                    printf("Snoopy n'a pas pousse le bloc\n");
                } else if (deplacement == 5) {
                    (snoopy->positionLigne)--;
                    printf("Snoopy n'a pas pousse le bloc\n");
                } else if (deplacement == 4) {
                    (snoopy->positionColonne)++;
                    printf("Snoopy n'a pas pousse le bloc\n");
                } else if (deplacement == 6) {
                    (snoopy->positionColonne)--;
                    printf("Snoopy n'a pas pousse le bloc\n");
                }
                break;
            default:
                printf("Snoopy n'a pas pousse le bloc\n");
                return;
        }
    }

    if (matrice[snoopy->positionLigne][snoopy->positionColonne] == 1) {
        printf("Un bloc cassable ! Touche 7 pour le casser sinon touche 9\n");
        scanf("%d", &decision);

        switch (decision) {
            case 7: // Bloc casse
                if (snoopy->positionLigne == blocCassable1->positionLigne) {
                    if (deplacement == 8) {
                        blocCassable1->casse--;
                        (snoopy->positionLigne)++;
                        matrice[blocCassable1->positionLigne][blocCassable1->positionColonne] = 0;
                        printf("Le bloc a ete casse");
                    } else if (deplacement == 5) {
                        blocCassable1->casse--;
                        (snoopy->positionLigne)--;
                        matrice[blocCassable1->positionLigne][blocCassable1->positionColonne] = 0;
                        printf("Le bloc a ete casse");
                    } else if (deplacement == 4) {
                        blocCassable1->casse--;
                        (snoopy->positionColonne)++;
                        matrice[blocCassable1->positionLigne][blocCassable1->positionColonne] = 0;
                        printf("Le bloc a ete casse");
                    } else if (deplacement == 6) {
                        blocCassable1->casse--;
                        (snoopy->positionColonne)--;
                        matrice[blocCassable1->positionLigne][blocCassable1->positionColonne] = 0;
                        printf("Le bloc a ete casse");
                    }
                }
                break;
            case 9: // Bloc pas cassé
                if (deplacement == 8) {
                    (snoopy->positionLigne)++;
                    printf("Snoopy n'a pas casse le bloc\n");
                } else if (deplacement == 5) {
                    (snoopy->positionLigne)--;
                    printf("Snoopy n'a pas pousse le bloc\n");
                } else if (deplacement == 4) {
                    (snoopy->positionColonne)++;
                    printf("Snoopy n'a pas pousse le bloc\n");
                } else if (deplacement == 6) {
                    (snoopy->positionColonne)--;
                    printf("Snoopy n'a pas pousse le bloc\n");
                }
                break;
            default:
                printf("Snoopy n'a pas pousse le bloc\n");
                return;
        }
    }

    if (snoopy->positionLigne >= 0 && snoopy->positionLigne < NOMBRELIGNE && snoopy->positionColonne >= 0 &&
        snoopy->positionColonne < NOMBRECOLONNE) {
        matrice[blocPoussable1->positionLigne][blocPoussable1->positionColonne] = 2;
        matrice[blocPoussable2->positionLigne][blocPoussable2->positionColonne] = 2;
        matrice[anciennePositionLigneSnoopy][anciennePositionColonneSnoopy] = 0;
        matrice[snoopy->positionLigne][snoopy->positionColonne] = 8;
    } else {
        if (deplacement == 8) {
            (snoopy->positionLigne)++;
            printf("Snoopy ne peut pas sortir du jeu\n");
        } else if (deplacement == 5) {
            (snoopy->positionLigne)--;
            printf("Snoopy ne peut pas sortir du jeu\n");
        } else if (deplacement == 4) {
            (snoopy->positionColonne)++;
            printf("Snoopy ne peut pas sortir du jeu\n");
        } else if (deplacement == 6) {
            (snoopy->positionColonne)--;
            printf("Snoopy ne peut pas sortir du jeu\n");
        }
    }
}