//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_STRUCTURESNOOPY_H
#define SNOOPYPROJET_STRUCTURESNOOPY_H

typedef struct Snoopy Snoopy;

struct Snoopy{
    int positionLigne;
    int positionColonne;
    int nombreDeVie;
};

#endif //SNOOPYPROJET_STRUCTURESNOOPY_H
