//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_STRUCTUREBLOCPOUSSABLE_H
#define SNOOPYPROJET_STRUCTUREBLOCPOUSSABLE_H

typedef struct BlocPoussable BlocPoussable;

struct BlocPoussable{
    int positionLigne;
    int positionColonne;
    int poussable;
};


#endif //SNOOPYPROJET_STRUCTUREBLOCPOUSSABLE_H
