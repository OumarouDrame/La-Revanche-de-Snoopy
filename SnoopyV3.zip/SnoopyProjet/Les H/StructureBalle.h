//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_STRUCTUREBALLE_H
#define SNOOPYPROJET_STRUCTUREBALLE_H

typedef struct Balle Balle;

struct Balle{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPYPROJET_STRUCTUREBALLE_H
