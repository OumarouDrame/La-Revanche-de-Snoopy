//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_DEPLACEMENTBALLE_H
#define SNOOPYPROJET_DEPLACEMENTBALLE_H

#include "../Les H/DimmensionMatrice.h"

void DeplacementBalle(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Balle* balle);

#endif //SNOOPYPROJET_DEPLACEMENTBALLE_H
