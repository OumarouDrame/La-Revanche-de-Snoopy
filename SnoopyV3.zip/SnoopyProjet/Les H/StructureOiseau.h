//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_STRUCTUREOISEAU_H
#define SNOOPYPROJET_STRUCTUREOISEAU_H

typedef struct Oiseau Oiseau;

struct Oiseau{
    int positionLigne;
    int positionColonne;
    int nombreOiseau;
};

#endif //SNOOPYPROJET_STRUCTUREOISEAU_H
