//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_STRUCTUREBLOCPIEGE_H
#define SNOOPYPROJET_STRUCTUREBLOCPIEGE_H

typedef struct BlocPiege BlocPiege;

struct BlocPiege{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPYPROJET_STRUCTUREBLOCPIEGE_H
