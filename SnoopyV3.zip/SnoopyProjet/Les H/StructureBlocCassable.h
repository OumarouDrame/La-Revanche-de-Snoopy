//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_STRUCTUREBLOCCASSABLE_H
#define SNOOPYPROJET_STRUCTUREBLOCCASSABLE_H

typedef struct BlocCassable BlocCassable;

struct BlocCassable{
    int positionLigne;
    int positionColonne;
    int casse;
};

#endif //SNOOPYPROJET_STRUCTUREBLOCCASSABLE_H
