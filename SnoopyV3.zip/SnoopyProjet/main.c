#include <stdio.h>
#include <stdlib.h>
#include "Les H/DimmensionMatrice.h"
#include "Les H/AfficherMatrice.h"

#include "Les H/StructureSnoopy.h"
#include "Les H/StructureOiseau.h"
#include "Les H/StructureBalle.h"
#include "Les H/StructureBlocPoussable.h"
#include "Les H/StructureBlocPiege.h"
#include "Les H/StructureBlocCassable.h"

#include "Les H/SnoopyDansMatrice.h"
#include "Les H/OiseauDansMatrice.h"
#include "Les H/BalleDansMatrice.h"
#include "Les H/BlocPoussableDansMatrice.h"
#include "Les H/BlocPiegeDansMatrice.h"
#include "Les H/BlocCassableDansMatrice.h"

#include "Les H/DeplacementSnoopy.h"
#include "Les H/DeplacementBalle.h"

#include "Les H/Sauvegarde.h"



int main() {

    int matrice[NOMBRELIGNE][NOMBRECOLONNE] = {0};

    Snoopy snoopy = {NOMBRELIGNE/2,NOMBRECOLONNE/2,3};
    Oiseau oiseau1 = {0,0, 1};
    Oiseau oiseau2 = {0,NOMBRECOLONNE-1, 1};
    Oiseau oiseau3 = {NOMBRELIGNE-1,0, 1};
    Oiseau oiseau4 = {NOMBRELIGNE-1,NOMBRECOLONNE-1, 1};
    BlocPoussable blocPoussable1 = {NOMBRELIGNE/2-1,NOMBRECOLONNE/3, 1};
    BlocPoussable blocPoussable2 = {NOMBRELIGNE-2,NOMBRECOLONNE-2, 1};
    BlocCassable blocCassable = {NOMBRELIGNE/2-2, NOMBRECOLONNE/2,1};

    BlocPiege blocPiege;

    //Balle balle = {2,0};

    SnoopyDansMatrice(matrice, &snoopy);
    OiseauDansMatrice(matrice, &oiseau1);
    OiseauDansMatrice(matrice,&oiseau2);
    OiseauDansMatrice(matrice,&oiseau3);
    OiseauDansMatrice(matrice,&oiseau4);
    BlocPoussableDansMatrice(matrice, &blocPoussable1, &blocPoussable2);
    BlocCassableDansMatrice(matrice, &blocCassable);
    BlocPiegeDansMatrice(matrice);

    //BalleDansMatrice(matrice, &balle);


    //MenuDuJeu(matrice, &snoopy, &blocPoussable1, &blocPoussable2,&blocCassable, &oiseau1, &oiseau2, &oiseau3, &oiseau4);

    int choix;
    printf("\nLa revanche de snoopy !\n\n 1 - Jouer\n 2 - Charger une partie\n 3 - Quitter\n\n");
    scanf("%d", &choix);
    switch (choix) {
        case 1:

            printf("\nNouvelle partie lance !\n");
            do
            {
                AfficherMatrice(matrice);
                DeplacementSnoopy(matrice, &snoopy, &blocPoussable1, &blocPoussable2, &blocCassable, &oiseau1, &oiseau2, &oiseau3, &oiseau4);
                Sauvegarde(&snoopy, &blocPoussable1, &blocPoussable2,&blocCassable, &oiseau1, &oiseau2, &oiseau3, &oiseau4);
                //DeplacementBalle(matrice, &balle);
            } while (1);

            break;

        case 2:

            FILE* fichier = NULL;

            fichier = fopen("Sauvegarde.txt","r+");

            if (fichier != NULL)
            {
                fscanf(fichier, "%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d", &(snoopy.positionLigne), &(snoopy.positionColonne), &(snoopy.nombreDeVie),
                       &(blocPoussable1.positionLigne), &(blocPoussable1.positionColonne), &(blocPoussable1.poussable),
                       &(blocPoussable2.positionLigne), &(blocPoussable2.positionColonne), &(blocPoussable2.poussable),
                       &(blocCassable.positionLigne), &(blocCassable.positionColonne), &(blocCassable.casse),
                       &(oiseau1.positionLigne), &(oiseau1.positionColonne), &(oiseau1.nombreOiseau), &(oiseau2.positionLigne),
                       &(oiseau2.positionColonne), &(oiseau2.nombreOiseau), &(oiseau3.positionLigne), &(oiseau3.positionColonne),
                       &(oiseau3.nombreOiseau), &(oiseau4.positionLigne), &(oiseau4.positionColonne), &(oiseau4.nombreOiseau));
                fclose(fichier);
            }
            else
            {
                printf("Impossible d'ouvrir la partie sauvegarde");
            }

            if (oiseau1.positionLigne == 99){
                matrice[0][0] = 0;
            }
            if (oiseau2.positionLigne == 99){
                matrice[0][NOMBRECOLONNE-1] = 0;
            }
            if (oiseau3.positionLigne == 99){
                matrice[NOMBRELIGNE-1][0] = 0;
            }
            if (oiseau4.positionLigne == 99){
                matrice[NOMBRELIGNE-1][NOMBRECOLONNE-1] = 0;
            }

            do
            {
                AfficherMatrice(matrice);
                DeplacementSnoopy(matrice, &snoopy, &blocPoussable1, &blocPoussable2, &blocCassable, &oiseau1, &oiseau2, &oiseau3, &oiseau4);
                Sauvegarde(&snoopy, &blocPoussable1, &blocPoussable2,&blocCassable, &oiseau1, &oiseau2, &oiseau3, &oiseau4);
                //DeplacementBalle(matrice, &balle);
            } while (1);

            break;
        case 3:

            printf("\nVous avez quitte le jeu.\n");
            exit(0);

            break;
        default:
            printf("Mauvais choix");
    }

    return 0;
}
