//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_OISEAUDANSMATRICE_H
#define SNOOPYPROJET_OISEAUDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void OiseauDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Oiseau* oiseau);

#endif //SNOOPYPROJET_OISEAUDANSMATRICE_H
