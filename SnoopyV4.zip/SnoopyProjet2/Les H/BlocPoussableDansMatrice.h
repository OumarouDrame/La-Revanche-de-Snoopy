//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_BLOCPOUSSABLEDANSMATRICE_H
#define SNOOPYPROJET_BLOCPOUSSABLEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BlocPoussableDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], BlocPoussable* blocPoussable1, BlocPoussable* blocPoussable2);

#endif //SNOOPYPROJET_BLOCPOUSSABLEDANSMATRICE_H
