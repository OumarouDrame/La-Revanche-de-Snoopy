//
// Created by Oumarou Dramé on 03/12/2023.
//

#ifndef SNOOPYPROJET_TIMER_H
#define SNOOPYPROJET_TIMER_H

void Timer(Snoopy* snoopy);

#endif //SNOOPYPROJET_TIMER_H
