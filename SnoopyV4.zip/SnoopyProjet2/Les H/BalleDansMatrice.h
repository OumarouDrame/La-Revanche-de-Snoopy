//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_BALLEDANSMATRICE_H
#define SNOOPYPROJET_BALLEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BalleDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Balle* balle);

#endif //SNOOPYPROJET_BALLEDANSMATRICE_H
