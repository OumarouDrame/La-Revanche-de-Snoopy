//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_AFFICHERMATRICE_H
#define SNOOPYPROJET_AFFICHERMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void AfficherMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE]);

#endif //SNOOPYPROJET_AFFICHERMATRICE_H
