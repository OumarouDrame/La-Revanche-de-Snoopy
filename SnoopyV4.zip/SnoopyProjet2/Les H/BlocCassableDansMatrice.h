//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_BLOCCASSABLEDANSMATRICE_H
#define SNOOPYPROJET_BLOCCASSABLEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BlocCassableDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], BlocCassable* blocCassable);

#endif //SNOOPYPROJET_BLOCCASSABLEDANSMATRICE_H
