//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_BLOCPIEGEDANSMATRICE_H
#define SNOOPYPROJET_BLOCPIEGEDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void BlocPiegeDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE]);

#endif //SNOOPYPROJET_BLOCPIEGEDANSMATRICE_H
