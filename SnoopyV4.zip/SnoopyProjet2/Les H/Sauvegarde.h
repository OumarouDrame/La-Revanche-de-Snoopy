//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_SAUVEGARDE_H
#define SNOOPYPROJET_SAUVEGARDE_H

void Sauvegarde(Snoopy* snoopy, BlocPoussable* blocPoussable1, BlocPoussable* blocPoussable2, BlocCassable* blocCassable1, Oiseau* oiseau1,Oiseau* oiseau2, Oiseau* oiseau3, Oiseau* oiseau4);

#endif //SNOOPYPROJET_SAUVEGARDE_H
