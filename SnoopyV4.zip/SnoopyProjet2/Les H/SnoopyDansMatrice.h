//
// Created by Oumarou Dramé on 12/11/2023.
//

#ifndef SNOOPYPROJET_SNOOPYDANSMATRICE_H
#define SNOOPYPROJET_SNOOPYDANSMATRICE_H

#include "../Les H/DimmensionMatrice.h"

void SnoopyDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Snoopy* snoopy);

#endif //SNOOPYPROJET_SNOOPYDANSMATRICE_H
