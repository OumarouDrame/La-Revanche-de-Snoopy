//
// Created by Oumarou Dramé on 03/12/2023.
//
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "../Les H/StructureSnoopy.h"

void Timer(Snoopy* snoopy){

        while (snoopy->temps > 0) {
            sleep(1);
            (snoopy->temps)--;
        }

    snoopy->nombreDeVie--;
    printf("\nLe temps s'est ecoule !\nSnoopy n'a plus que : %d vies.\n", snoopy->nombreDeVie);
    }
