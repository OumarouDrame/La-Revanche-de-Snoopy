//
// Created by Oumarou Dramé on 12/11/2023.
//

#include "../Les H/StructureOiseau.h"
#include "../Les H/DimmensionMatrice.h"

void OiseauDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Oiseau* oiseau)
{
    matrice[oiseau->positionLigne][oiseau->positionColonne] = 9;
}