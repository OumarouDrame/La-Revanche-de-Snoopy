//
// Created by Oumarou Dramé on 12/11/2023.
//

#include <stdio.h>
#include <stdlib.h>
#include "../Les H/DimmensionMatrice.h"

void AfficherMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE])
{
    printf("\n --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- \n");
    for (int i = 0; i < NOMBRELIGNE; i++) {
        for (int j = 0; j < NOMBRECOLONNE; j++) {

            if (j == NOMBRECOLONNE-1) {
                printf("| %d |", matrice[i][j]);
            } else {
                printf("| %d ", matrice[i][j]);
            }
        }
        printf("\n --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- \n");
    }
}
