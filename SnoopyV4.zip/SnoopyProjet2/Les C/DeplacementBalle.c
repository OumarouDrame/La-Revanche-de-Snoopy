//
// Created by Oumarou Dramé on 12/11/2023.
//

#include "../Les H/StructureBalle.h"
#include "../Les H/DimmensionMatrice.h"

void DeplacementBalle(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Balle* balle) {

    int anciennePositionLigne = balle->positionLigne;
    int anciennePositionColonne = balle->positionColonne;
    (balle->positionLigne)++;
    (balle->positionColonne)++;
    matrice[balle->positionLigne][balle->positionColonne] = 7;
    matrice[anciennePositionLigne][anciennePositionColonne] = 0;
}
