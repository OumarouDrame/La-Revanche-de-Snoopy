//
// Created by Oumarou Dramé on 12/11/2023.
//

#include "../Les H/StructureBlocCassable.h"
#include "../Les H/DimmensionMatrice.h"

void BlocCassableDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], BlocCassable* blocCassable)
{
    matrice[blocCassable->positionLigne][blocCassable->positionColonne] = 1;
}

