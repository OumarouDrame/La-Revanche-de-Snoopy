//
// Created by oulag on 28/10/2023.
//

//Dimensions de la matrice
#define lignes 10
#define colonnes 20

#ifndef PROJETJEUSNOOPY_BIBLIOTHEQUES_H
#define PROJETJEUSNOOPY_BIBLIOTHEQUES_H

// entête de la fonction d'initialisation de la matrice
void initialiserMatrice(char matrice[lignes][colonnes]);

// entêtes des fonctions de placement des elements dans de la matrice
void PositionOiseaux(char matrice[lignes][colonnes]);
void PositionBlocPoussable(char matrice[lignes][colonnes]);
void PositionBlocCassable(char matrice[lignes][colonnes]);
void PositionBlocPieges(char matrice[lignes][colonnes]);


// entête de la fonction d'affichage de contenu de la matrice
void AffichageMatrice(char matrice[lignes][colonnes]);

// la stucture CoordonneeEtVies
        typedef struct {
            int coordonneeX;
            int coordonneeY;
            int vies;
        } CoordonneesEtVies;

//entête de la fonction de vérification en Haut
CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);

//entête de la fonction de vérification en Bas
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);

//entête de la fonction de vérification à Gauche
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies);

//entête de la fonction de vérification à Droite
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies);




#endif //PROJETJEUSNOOPY_BIBLIOTHEQUES_H
