#include <stdio.h>


//Dimensions de la matrice
#define lignes 10
#define colonnes 20

//Définition des élements de la matrice en macros
#define SNOOPY 'S'
#define OISEAU 'O'
#define POUSSABLE 'P'
#define CASSABLE 'C'
#define PIEGE 'K'
#define BALLE 'X'

// Fonction pour initialiser la matrice
void initialiserMatrice(char matrice[lignes][colonnes]) {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            matrice[i][j] = '.';
        }
    }

}

//fonctions de placement des élements dans la matrice
void PositionOiseaux(char matrice[lignes][colonnes]){
    // Placement des oiseaux dans les coins de la matrice avec la symbol 'O' stocké dans OISEAU
    matrice[0][0] = OISEAU;
    matrice[0][colonnes - 1] = OISEAU;
    matrice[lignes - 1][0] = OISEAU;
    matrice[lignes - 1][colonnes - 1] = OISEAU;
}
void PositionBlocPoussable(char matrice[lignes][colonnes]){
    // Placement de 3 blocs poussables (stocké dans POUSSABLE en macros)
    matrice[5][6] = POUSSABLE;
    matrice[7][0] = POUSSABLE;
    matrice[2][3] = POUSSABLE;
}

void PositionBlocCassable(char matrice[lignes][colonnes]){
    // Placement de 3 blocs cassables (stocké dans CASSABLE en macros)
    matrice[6][19] = CASSABLE;
    matrice[4][7] = CASSABLE;
    matrice[6][10] = CASSABLE;
}

void PositionBlocPieges(char matrice[lignes][colonnes]){
    // Placement de 3 blocs pieges (stocké dans PIEGE en macros)
    matrice[0][3] = PIEGE;
    matrice[7][4] = PIEGE;
    matrice[9][10] = PIEGE;
    matrice[5][19] = PIEGE;
}

//fonction d'affichage de la matrice
void AffichageMatrice(char matrice[lignes][colonnes]){
    // Affichage de la matrice
    for (int i = 0; i < lignes; i++) {
        for (int j = 0; j < colonnes; j++) {
            printf("%c ", matrice[i][j]);
        }
        printf("\n");
    }
}

// Définition de la structure CoordonneesEtVies comme type de retour des fonctions suivantes
typedef struct {
    int coordonneeX;
    int coordonneeY;
    int vies;
} CoordonneesEtVies;

// Fonction de vérification si le pas suivant de snoopy en Haut correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierHaut(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        //CasserBloc();
        //Snoopy se deplace en haut
        coordonneeY--;
    } else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        //PousserBloc();
        //Snoopy se deplace en haut
        coordonneeY--;
    } else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n ");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n ");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeY--;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy en Bas correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierBas(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[a][coordonneeX] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        //CasserBloc();
        //Snoopy se deplace en haut
        coordonneeY++;
    } else if(matrice[a][coordonneeX] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        //PousserBloc();
        //Snoopy se deplace en haut
        coordonneeY++;
    } else if(matrice[a][coordonneeX] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n ");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n ");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeY = coordonneeY;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeY++;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy à gauche correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierGauche(char matrice[lignes][colonnes], int coordonneeX, int coordonneeY, int a, int vies) {
    CoordonneesEtVies resultat;

    if (matrice[coordonneeY][a] == CASSABLE) {
        printf("il y'a un bloc cassable\n");
        // CasserBloc();
        coordonneeX--;
    } else if (matrice[coordonneeY][a] == POUSSABLE) {
        printf("il y'a un bloc POUSSABLE\n");
        // PousserBloc();
        coordonneeX--;
    } else if (matrice[coordonneeY][a] == PIEGE) {
        printf("il y'a un bloc PIEGE\n");
        coordonneeX = coordonneeX;
        vies--;
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n");
        printf("Nombre de vies restantes = %d\n", vies);
    } else {
        coordonneeX--;
    }

    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}

// Fonction de vérification si le pas suivant de snoopy à Droite correspond à un Bloc cassabe, poussable, piege ou vide
CoordonneesEtVies VerifierDroite(char matrice[lignes][colonnes],int coordonneeX, int coordonneeY, int a , int vies){
    CoordonneesEtVies resultat;
    if(matrice[coordonneeY][a] == CASSABLE){
        printf("il y'a un bloc cassable\n ");
        //CasserBloc();
        //Snoopy se deplace à droite
        coordonneeX++;
    } else if(matrice[coordonneeY][a] == POUSSABLE){
        printf("il y'a un bloc POUSSABLE\n");
        //PousserBloc();
        //Snoopy se deplace à droite
        coordonneeX++;
    } else if(matrice[coordonneeY][a] ==PIEGE){
        vies=vies-1;
        printf("il y'a un bloc PIEGE\n");
        printf("Attention ! vous etes passe par un bloc piege\n");
        printf("Malheureusement Snoopy a perdu une vie\n");
        printf("Nombre de vie restante = %d\n",vies);
        coordonneeX = coordonneeX;  //Les coordonnées de snoopy ne change pas

    }else{
        //Snoopy se deplace à droite
        coordonneeX++;
    }
    // Remplir la structure avec les coordonnées et le nombre de vies
    resultat.coordonneeX = coordonneeX;
    resultat.coordonneeY = coordonneeY;
    resultat.vies = vies;

    return resultat;
}



