#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Bibliotheques.h"

//Définition des élements de la matrice en macros
#define SNOOPY 'S'
#define OISEAU 'O'
#define POUSSABLE 'P'
#define CASSABLE 'C'
#define PIEGE 'K'
#define BALLE 'X'


int main() {

    //Nombre des vie de snoopy
    int viesSnoopy = 3;

    //Nombre de oiseaux à recupérer
    int oiseauxRestants = 4;

    //Declaration de deux variables
    int CoordonneeXCase = 0;
    int CoordonneeYCase = 0;

    // Déclaration de la matrice de type char
    char Matrice[lignes][colonnes];

    //Initialisation de la matrice
    initialiserMatrice( Matrice);

    //Position des Oiseaux dans la matrice
    PositionOiseaux(Matrice);

    //Position des Blocs Poussables dans la matrice
    PositionBlocPoussable(Matrice);

    //Position des Blocs Cassables dans la matrice
    PositionBlocCassable(Matrice);

    //Position des Blocs Pieges dans la matrice
    PositionBlocPieges(Matrice);


    //Coordonnées de Snoopy
    int snoopyX, snoopyY;

    // Placer Snoopy  dans une case où il n'a pas ni oiseaux ni blocs(cassable,Poussable,Pieges)
    do {
        snoopyX = rand() % colonnes;
        snoopyY = rand() % lignes;
    } while (Matrice[snoopyY][snoopyX] == OISEAU || Matrice[snoopyY][snoopyX] == POUSSABLE || Matrice[snoopyY][snoopyX] == CASSABLE || Matrice[snoopyX][snoopyY] == PIEGE);

    // Position initiale de Snoopy
    Matrice[snoopyY][snoopyX] = SNOOPY;


    // Boucle principale du jeu
    while (oiseauxRestants > 0 && viesSnoopy > 0) {
        AffichageMatrice(Matrice);

        // Demande à l'utilisateur de saisir une action spécifique
        printf("Entrez une action (h, b, g, d) : \n");
        char action[10];
        scanf("%s", action);

        // Efface la position actuelle de Snoopy si il se deplace vers n'importe quelle direction
        Matrice[snoopyY][snoopyX] = '.';


        // Traitement de l'action
        if (strcmp(action, "h") == 0 && snoopyY > 0) {
            CoordonneeYCase = snoopyY-1;
            CoordonneesEtVies resultatH = VerifierHaut(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatH.coordonneeY;
            viesSnoopy = resultatH.vies;
        }
        else if (strcmp(action, "b") == 0 && snoopyY < lignes - 1) {
            //les coordonnees suivant Y du pas suivant de Snoopy pour verifier
            CoordonneeYCase = snoopyY+1;
            CoordonneesEtVies resultatB = VerifierBas(Matrice, snoopyX, snoopyY, CoordonneeYCase, viesSnoopy);
            snoopyY = resultatB.coordonneeY;
            viesSnoopy = resultatB.vies;
        }
        else if (strcmp(action, "g") == 0 && snoopyX > 0) {
            CoordonneeXCase = snoopyX - 1;
            CoordonneesEtVies resultatG = VerifierGauche(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatG.coordonneeX;
            viesSnoopy = resultatG.vies;
        }
        else if (strcmp(action, "d") == 0 && snoopyX < colonnes - 1) {
            CoordonneeXCase = snoopyX + 1;    //la valeur suivant X de la case
            CoordonneesEtVies resultatD = VerifierDroite(Matrice, snoopyX, snoopyY, CoordonneeXCase, viesSnoopy);
            snoopyX = resultatD.coordonneeX;
            viesSnoopy = resultatD.vies;
        }
        else{
            printf("Attention tu dois choisir une autre direction !\n");
        }

        // Vérifie si Snoopy a collecté un oiseau
        if (Matrice[snoopyY][snoopyX] == 'O') {
            oiseauxRestants--;
            Matrice[snoopyY][snoopyX] = 'S';
            printf("Felicitations ! Vous avez collecte un oiseau. Oiseaux restants : %d\n", oiseauxRestants);
        }
        else {
            //Snoopy se deplace ves la direction saisie si la case ne contient pas un oiseau
            Matrice[snoopyY][snoopyX] = 'S';
        }
    }

    //Vérification il y'a encore de oiseau à collecter ou si snoopy possede encore des vies pour continuer le niveau
    if (oiseauxRestants == 0 && viesSnoopy >= 0) {
    printf("Bravo ! Vous avez collecte tous les oiseaux.\n");
    } else {
    printf("Snoopy n'a plus de vies. Le jeu est termine.\n");
    exit(0);
    }

return 0;
}

