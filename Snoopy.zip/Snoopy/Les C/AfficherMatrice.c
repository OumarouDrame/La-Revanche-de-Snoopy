//
// Created by Oumarou Dramé on 25/10/2023.
//
#include <stdio.h>
#define NOMBRELIGNE 4
#define NOMBRECOLONNE 4

void AfficherMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE])
{
    printf("\n --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- \n");
    for (int i = 0; i < NOMBRELIGNE; i++) {
        for (int j = 0; j < NOMBRECOLONNE; j++) {

            if (j == NOMBRECOLONNE-1) {
                printf("| %d |", matrice[i][j]);
            } else {
                printf("| %d ", matrice[i][j]);
            }
        }
        printf("\n --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- --- \n");
    }
}