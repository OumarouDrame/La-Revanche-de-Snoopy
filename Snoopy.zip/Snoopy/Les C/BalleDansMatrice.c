//
// Created by Oumarou Dramé on 26/10/2023.
//

#include "../Les H/StructureBalle.h"
#define NOMBRELIGNE 4
#define NOMBRECOLONNE 4

void BalleDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Balle* balle)
{
    matrice[balle->positionLigne][balle->positionColonne] = 7;
}
