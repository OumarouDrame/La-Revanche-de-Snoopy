//
// Created by Oumarou Dramé on 26/10/2023.
//

#include "../Les H/StructureBalle.h"
#define NOMBRELIGNE 10
#define NOMBRECOLONNE 20

void DeplacementBalle(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Balle* balle) {

    int anciennePositionLigne;
    int anciennePositionColonne;

    do {
        anciennePositionLigne = balle->positionLigne;
        anciennePositionColonne = balle->positionColonne;
        (balle->positionLigne)++;
        (balle->positionColonne)++;
        matrice[balle->positionLigne][balle->positionColonne] = 7;
        matrice[anciennePositionLigne][anciennePositionColonne] = 0;
    } while (balle->positionColonne == 19);
}