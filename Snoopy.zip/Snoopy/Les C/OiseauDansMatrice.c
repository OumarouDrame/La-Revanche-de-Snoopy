//
// Created by Oumarou Dramé on 25/10/2023.
//

#include "../Les H/StructureOiseau.h"
#define NOMBRELIGNE 4
#define NOMBRECOLONNE 4

void OiseauDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Oiseau* oiseau)
{
    matrice[oiseau->positionLigne][oiseau->positionColonne] = 9;
}
