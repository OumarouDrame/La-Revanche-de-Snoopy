//
// Created by Oumarou Dramé on 25/10/2023.
//

#include "../Les H/StructureSnoopy.h"
#define NOMBRELIGNE 4
#define NOMBRECOLONNE 4

void SnoopyDansMatrice(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Snoopy* snoopy)
{
    matrice[snoopy->positionLigne][snoopy->positionColonne] = 8;
}