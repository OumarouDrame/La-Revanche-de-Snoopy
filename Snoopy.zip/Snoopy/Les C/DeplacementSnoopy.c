//
// Created by Oumarou Dramé on 25/10/2023.
//

#include "../Les H/StructureSnoopy.h"
#define NOMBRELIGNE 4
#define NOMBRECOLONNE 4

void DeplacementSnoopy(int matrice[NOMBRELIGNE][NOMBRECOLONNE], Snoopy* snoopy) {

    int deplacement = 0;
    int anciennePositionLigne = snoopy->positionLigne;
    int anciennePositionColonne = snoopy->positionColonne;

    printf("Fais bouger Snoopy\n");
    scanf("%d", &deplacement);

    switch (deplacement) {
        case 8: // Haut
            (snoopy->positionLigne)--;
            break;
        case 5: // Bas
            (snoopy->positionLigne)++;
            break;
        case 4: // Gauche
            (snoopy->positionColonne)--;
            break;
        case 6: // Droite
            (snoopy->positionColonne)++;
            break;
        default:
            printf("Mouvement invalide\n");
            return;
    }

    if (snoopy->positionLigne >= 0 && snoopy->positionLigne < NOMBRELIGNE && snoopy->positionColonne >= 0 && snoopy->positionColonne < NOMBRECOLONNE)
    {
    matrice[snoopy->positionLigne][snoopy->positionColonne] = 8;
    matrice[anciennePositionLigne][anciennePositionColonne] = 0;
    }
    else{
        if(deplacement == 8){
            (snoopy->positionLigne)++;
            printf("Interdit de sortir du jeu\n");
        }
        else if (deplacement == 5){
            (snoopy->positionLigne)--;
            printf("Interdit de sortir du jeu\n");
        }
        else if (deplacement == 4){
            (snoopy->positionColonne)++;
            printf("Interdit de sortir du jeu\n");
        }
        else if (deplacement == 6){
            (snoopy->positionColonne)--;
            printf("Interdit de sortir du jeu\n");
        }
    }
}

