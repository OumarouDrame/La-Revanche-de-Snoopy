#include <stdio.h>
#include "Les H/StructureSnoopy.h"
#include "Les H/StructureOiseau.h"
#include "Les H/StructureBalle.h"
#include "Les H/AfficherMatrice.h"
#include "Les H/SnoopyDansMatrice.h"
#include "Les H/OiseauDansMatrice.h"
#include "Les H/BalleDansMatrice.h"
#include "Les H/DeplacementSnoopy.h"
#include "Les H/DeplacementBalle.h"

#define NOMBRELIGNE 4
#define NOMBRECOLONNE 4

int main() {

    int matrice[NOMBRELIGNE][NOMBRECOLONNE] = {0};

    Snoopy snoopy = {NOMBRELIGNE/2,NOMBRECOLONNE/2};

    Oiseau oiseau1 = {0,0};
    Oiseau oiseau2 = {0,NOMBRECOLONNE-1};
    Oiseau oiseau3 = {NOMBRELIGNE-1,0};
    Oiseau oiseau4 = {NOMBRELIGNE-1,NOMBRECOLONNE-1};

    //Balle balle = {1,1};

    SnoopyDansMatrice(matrice, &snoopy);

    OiseauDansMatrice(matrice, &oiseau1);
    OiseauDansMatrice(matrice, &oiseau2);
    OiseauDansMatrice(matrice, &oiseau3);
    OiseauDansMatrice(matrice, &oiseau4);

    //BalleDansMatrice(matrice, &balle);

    do
    {
    AfficherMatrice(matrice);
    DeplacementSnoopy(matrice, &snoopy);
    } while (1);

    return 0;
}
