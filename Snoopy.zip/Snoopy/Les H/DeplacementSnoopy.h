//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_DEPLACEMENTSNOOPY_H
#define SNOOPY_DEPLACEMENTSNOOPY_H

void DeplacementSnoopy(int matrice[10][20], Snoopy* snoopy);

#endif //SNOOPY_DEPLACEMENTSNOOPY_H
