//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_SNOOPYDANSMATRICE_H
#define SNOOPY_SNOOPYDANSMATRICE_H

void SnoopyDansMatrice(int matrice[10][20], Snoopy* snoopy);

#endif //SNOOPY_SNOOPYDANSMATRICE_H
