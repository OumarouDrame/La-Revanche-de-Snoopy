//
// Created by Oumarou Dramé on 26/10/2023.
//

#ifndef SNOOPY_DEPLACEMENTBALLE_H
#define SNOOPY_DEPLACEMENTBALLE_H

void DeplacementBalle(int matrice[10][20], Balle* balle);

#endif //SNOOPY_DEPLACEMENTBALLE_H
