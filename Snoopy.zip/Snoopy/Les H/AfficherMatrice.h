//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_AFFICHERMATRICE_H
#define SNOOPY_AFFICHERMATRICE_H

void AfficherMatrice(int matrice[10][20]);

#endif //SNOOPY_AFFICHERMATRICE_H
