//
// Created by Oumarou Dramé on 26/10/2023.
//

#ifndef SNOOPY_BALLEDANSMATRICE_H
#define SNOOPY_BALLEDANSMATRICE_H

void BalleDansMatrice(int matrice[10][20], Balle* balle);

#endif //SNOOPY_BALLEDANSMATRICE_H
