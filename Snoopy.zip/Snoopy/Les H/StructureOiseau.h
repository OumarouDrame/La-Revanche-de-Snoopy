//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_STRUCTUREOISEAU_H
#define SNOOPY_STRUCTUREOISEAU_H

typedef struct Oiseau Oiseau;

struct Oiseau{
    int positionLigne;
    int positionColonne;
};

#endif //SNOOPY_STRUCTUREOISEAU_H
