//
// Created by Oumarou Dramé on 25/10/2023.
//

#ifndef SNOOPY_OISEAUDANSMATRICE_H
#define SNOOPY_OISEAUDANSMATRICE_H

void OiseauDansMatrice(int matrice[10][20], Oiseau* oiseau);

#endif //SNOOPY_OISEAUDANSMATRICE_H
